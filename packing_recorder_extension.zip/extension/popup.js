// ============================================================
//  PACKING RECORDER POPUP SCRIPT (v2.0.0)
// ============================================================

const masterToggle = document.getElementById('master-toggle');
const toggleLabel = document.getElementById('toggle-label');
const toggleSub = document.getElementById('toggle-sub');

const authDot = document.getElementById('auth-dot');
const authText = document.getElementById('auth-text');
const btnLogin = document.getElementById('btn-login');
const btnLogout = document.getElementById('btn-logout');

const btnSettingsToggle = document.getElementById('btn-settings-toggle');
const settingsSection = document.getElementById('settings-section');
const settingsArrow = document.getElementById('settings-arrow');

const clientIdInput = document.getElementById('client-id-input');
const folderIdInput = document.getElementById('folder-id-input');
const btnSaveSettings = document.getElementById('btn-save-settings');
const driveLinkBox = document.getElementById('drive-link-box');
const driveFolderLink = document.getElementById('drive-folder-link');

let currentClientId = '';

// ------------------------------------------------------------
// INITIALIZATION
// ------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  // Load initial settings
  chrome.storage.local.get([
    'extension_enabled', 
    'access_token', 
    'user_info',
    'gcp_client_id',
    'gcp_folder_id'
  ], (data) => {
    
    // Toggle state
    const isEnabled = data.hasOwnProperty('extension_enabled') ? data.extension_enabled : true;
    masterToggle.checked = isEnabled;
    updateToggleUI(isEnabled);
    
    // Auth state
    updateAuthUI(data.access_token, data.user_info);
    
    // Settings state
    if (data.gcp_client_id) {
      clientIdInput.value = data.gcp_client_id;
      currentClientId = data.gcp_client_id;
    }
    if (data.gcp_folder_id) {
      folderIdInput.value = data.gcp_folder_id;
      driveLinkBox.classList.remove('hidden');
      driveFolderLink.href = `https://drive.google.com/drive/folders/${data.gcp_folder_id}`;
    }
  });
});

// ------------------------------------------------------------
// TOGGLE HANDLER
// ------------------------------------------------------------
masterToggle.addEventListener('change', (e) => {
  const isEnabled = e.target.checked;
  updateToggleUI(isEnabled);
  
  // Save to storage
  chrome.storage.local.set({ extension_enabled: isEnabled });
  
  // Inform active tabs
  chrome.tabs.query({url: "*://*.bigseller.com/*"}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { action: 'SET_ENABLED', enabled: isEnabled }).catch(()=>{} /* ignore disconnected */);
    });
  });
  // Inform mock page
  chrome.tabs.query({url: "http://127.0.0.1:5500/*"}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { action: 'SET_ENABLED', enabled: isEnabled }).catch(()=>{} /* ignore disconnected */);
    });
  });
});

function updateToggleUI(isEnabled) {
  if (isEnabled) {
    toggleLabel.textContent = '🟢 เปิดใช้งานอยู่';
    toggleLabel.style.color = 'var(--success)';
    toggleSub.textContent = 'Extension จะทำงานเมื่อเปิดหน้าสแกน';
  } else {
    toggleLabel.textContent = '⚪ ปิดใช้งาน';
    toggleLabel.style.color = 'var(--text-muted)';
    toggleSub.textContent = 'Extension หยุดทำงานชั่วคราว';
  }
}

// ------------------------------------------------------------
// AUTHENTICATION HANDLERS
// ------------------------------------------------------------
function updateAuthUI(token, userInfo) {
  if (token) {
    authDot.className = 'auth-dot active';
    authText.textContent = `Signed In: ${userInfo || 'User'}`;
    btnLogin.classList.add('hidden');
    btnLogout.classList.remove('hidden');
  } else {
    authDot.className = 'auth-dot inactive';
    authText.textContent = 'ยังไม่ได้ล็อกอิน (อัปโหลดไม่ได้)';
    btnLogin.classList.remove('hidden');
    btnLogout.classList.add('hidden');
  }
}

btnLogin.addEventListener('click', () => {
  btnLogin.textContent = '⏳ กำลังล็อกอิน...';
  btnLogin.disabled = true;
  
  chrome.runtime.sendMessage({ action: 'START_AUTH', clientId: currentClientId }, (response) => {
    btnLogin.disabled = false;
    btnLogin.textContent = '🔑 Sign In with Google';
    
    if (response && response.success) {
      updateAuthUI(response.access_token, response.user_info);
    } else {
      alert('Login failed: ' + (response ? response.error : 'Unknown Error'));
    }
  });
});

btnLogout.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'LOGOUT' }, () => {
    updateAuthUI(null, null);
  });
});

// ------------------------------------------------------------
// SETTINGS HANDLERS
// ------------------------------------------------------------
btnSettingsToggle.addEventListener('click', () => {
  const isHidden = settingsSection.classList.contains('hidden');
  if (isHidden) {
    settingsSection.classList.remove('hidden');
    settingsArrow.textContent = '▲';
  } else {
    settingsSection.classList.add('hidden');
    settingsArrow.textContent = '▼';
  }
});

btnSaveSettings.addEventListener('click', () => {
  const cid = clientIdInput.value.trim();
  const fid = folderIdInput.value.trim();
  
  if (!cid || !fid) {
    alert('กรุณากรอกข้อมูลให้ครบถ้วน');
    return;
  }
  
  const originalText = btnSaveSettings.textContent;
  btnSaveSettings.textContent = '⏳ กำลังบันทึก...';
  
  chrome.runtime.sendMessage({
    action: 'SAVE_SETTINGS',
    clientId: cid,
    folderId: fid
  }, (response) => {
    btnSaveSettings.textContent = '✅ บันทึกแล้ว';
    currentClientId = cid;
    
    if (fid) {
      driveLinkBox.classList.remove('hidden');
      driveFolderLink.href = `https://drive.google.com/drive/folders/${fid}`;
    }
    
    setTimeout(() => {
      btnSaveSettings.textContent = originalText;
    }, 2000);
  });
});
