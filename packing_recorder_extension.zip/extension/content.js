// ============================================================
//  PACKING RECORDER CONTENT SCRIPT
// ============================================================

// ============================================================
// State Variables
// ============================================================
let accessToken = null;
let clientId = null;
let folderId = null;
let autoRecordEnabled = true;
let isExtensionEnabled = true;

let mediaRecorder = null;
let recordedChunks = [];
let isRecording = false;
let lastFrameTime = 0;

// เก็บข้อมูลไฟล์ที่อัปโหลดไม่ผ่านไว้ใน RAM เพื่อให้กด Retry ได้
let lastFailedUpload = null;

let startTime = null;
let durationInterval = null;
let animationFrameId = null;

let streamVideo = null;
let canvasElement = null;
let canvasCtx = null;
let activeDeviceId = null;

let currentTrackingNo = '';
let currentOrderNo = '';
let currentLogistics = '';
let orderCheckInterval = null;

// ============================================================
// UI Elements
// ============================================================
let floatingPanel = null;
let durationBadge = null;
let trackingValEl = null;
let logisticsValEl = null;
let cameraSelect = null;
let autoRecordCheck = null;
let recordBtn = null;
let settingsPanel = null;

// ============================================================
// IndexedDB replacement - Sync storage history helper
// ============================================================
async function saveLogToHistory(logEntry) {
  const data = await chrome.storage.local.get(['scan_history']);
  let history = data.scan_history || [];
  
  // Insert at beginning
  history.unshift({
    id: Date.now(),
    created_at: new Date().toISOString(),
    ...logEntry
  });

  // Limit to 100 entries and clean up entries older than 3 days
  const now = Date.now();
  const threeDays = 3 * 24 * 60 * 60 * 1000;
  history = history.filter(item => {
    const age = now - new Date(item.created_at).getTime();
    return age < threeDays;
  }).slice(0, 100);

  await chrome.storage.local.set({ scan_history: history });
}

async function updateLogStatus(trackingNo, updates) {
  const data = await chrome.storage.local.get(['scan_history']);
  let history = data.scan_history || [];
  
  const index = history.findIndex(item => item.tracking_no === trackingNo);
  if (index !== -1) {
    history[index] = { ...history[index], ...updates };
    await chrome.storage.local.set({ scan_history: history });
  }
}

// ============================================================
// Initialize configurations from chrome storage
// ============================================================
async function loadConfig() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'GET_SETTINGS' }, (response) => {
      if (response && response.success) {
        const settings = response.settings;
        clientId = settings.gcp_client_id;
        folderId = settings.gcp_folder_id;
        accessToken = settings.access_token;
      }
      resolve();
    });
  });
}

// ============================================================
// Scrape Tracking Number and Logistics from DOM
// ============================================================
function scrapeTrackingAndLogistics() {
  // 1. Scrape Tracking No from <span class="tackingNo">
  const trackingEl = document.querySelector('span.tackingNo');
  if (trackingEl) {
    const txt = trackingEl.textContent.trim();
    if (txt && txt !== currentTrackingNo) {
      currentTrackingNo = txt;
      if (trackingValEl) trackingValEl.textContent = txt;
    }
  }

  // 2. Scrape Logistics from DOM containing "โลจิสติกส์"
  const elements = document.querySelectorAll('*');
  for (const el of elements) {
    if (el.children.length === 0 && el.textContent.includes('โลจิสติกส์')) {
      const parentTxt = el.parentElement ? el.parentElement.textContent.trim() : el.textContent.trim();
      const match = parentTxt.match(/โลจิสติกส์\s*(.*)/i);
      if (match && match[1]) {
        const logi = match[1].trim();
        if (logi && logi !== currentLogistics) {
          currentLogistics = logi;
          if (logisticsValEl) logisticsValEl.textContent = logi;
        }
        break;
      }
    }
  }
}

// ============================================================
// Start camera stream
// ============================================================
async function initCamera(deviceId = null) {
  if (streamVideo && streamVideo.srcObject) {
    streamVideo.srcObject.getTracks().forEach(t => t.stop());
  }

  const constraints = {
    video: {
      width: { ideal: 1280 },
      height: { ideal: 720 },
      frameRate: { ideal: 15 }
    },
    audio: false
  };

  if (deviceId) {
    constraints.video.deviceId = { exact: deviceId };
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    streamVideo.srcObject = stream;
    await streamVideo.play();
    
    // Hide camera error overlay if any
    const placeholder = floatingPanel.querySelector('.pr-placeholder');
    if (placeholder) placeholder.classList.add('hidden');
    
    // Save device ID
    if (deviceId) {
      activeDeviceId = deviceId;
      await chrome.storage.local.set({ selected_device_id: deviceId });
    }

    // Populate camera list
    populateCameraList();
  } catch (err) {
    console.error('Camera Init Error:', err);
    showUploadStatus('error', 'เปิดกล้องไม่ได้: ' + err.message);
    const placeholder = floatingPanel.querySelector('.pr-placeholder');
    if (placeholder) {
      placeholder.classList.remove('hidden');
      placeholder.innerHTML = `<span class="pr-placeholder-icon">❌</span><span>กรุณาอนุญาตสิทธิ์การเข้าถึงกล้อง</span>`;
    }
  }
}

// ============================================================
// Populate Camera Selector Dropdown
// ============================================================
async function populateCameraList() {
  if (!cameraSelect) return;
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const videoDevices = devices.filter(d => d.kind === 'videoinput');
    
    cameraSelect.innerHTML = '';
    videoDevices.forEach(d => {
      const opt = document.createElement('option');
      opt.value = d.deviceId;
      opt.textContent = d.label || `Camera ${cameraSelect.length + 1}`;
      if (d.deviceId === activeDeviceId) {
        opt.selected = true;
      }
      cameraSelect.appendChild(opt);
    });
  } catch (e) {
    console.warn('Failed to enumerate video devices:', e);
  }
}

// ============================================================
// Drawing Loop: Redraw camera frames to Canvas & add overlay metadata
// ============================================================
function drawCanvasLoop() {
  if (streamVideo && streamVideo.readyState >= 2 && !streamVideo.paused) {
    if (isRecording) {
      canvasCtx.drawImage(streamVideo, 0, 0, canvasElement.width, canvasElement.height);
      drawWatermark();
    } else {
      // Draw black screen
      canvasCtx.fillStyle = '#0a0a0a';
      canvasCtx.fillRect(0, 0, canvasElement.width, canvasElement.height);
      
      // Draw text
      canvasCtx.fillStyle = '#10b981'; // Green
      canvasCtx.font = 'bold 36px "Inter", sans-serif';
      canvasCtx.textAlign = 'center';
      canvasCtx.textBaseline = 'middle';
      canvasCtx.fillText('🎥 กล้องเชื่อมต่ออยู่', canvasElement.width / 2, canvasElement.height / 2 - 20);
      
      canvasCtx.fillStyle = '#94a3b8';
      canvasCtx.font = '24px "Inter", sans-serif';
      canvasCtx.fillText('พร้อมบันทึกวิดีโอ', canvasElement.width / 2, canvasElement.height / 2 + 30);
    }
  }
  animationFrameId = requestAnimationFrame(drawCanvasLoop);
}

// ============================================================
// Draw Watermark (Burn-in metadata) on recording canvas
// ============================================================
function drawWatermark() {
  // Scrape tracking info dynamically in loop so it updates during the video
  scrapeTrackingAndLogistics();

  const W = canvasElement.width;
  const H = canvasElement.height;
  
  // Format Date & Time: YYYY-MM-DD HH:MM:SS
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const dateStr = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
  const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  
  canvasCtx.save();
  
  // Outer Border Overlay (Blinking Red while recording)
  if (isRecording) {
    canvasCtx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
    canvasCtx.lineWidth = 8;
    canvasCtx.strokeRect(4, 4, W - 8, H - 8);
    
    // Blinking effect for recording indicator in corner
    if (Math.floor(Date.now() / 500) % 2 === 0) {
      canvasCtx.fillStyle = '#ef4444';
      canvasCtx.beginPath();
      canvasCtx.arc(35, 35, 10, 0, 2 * Math.PI);
      canvasCtx.fill();
    }
  }

  // Draw Translucent overlay box for text in the bottom right corner
  const boxW = 420;
  const boxH = 100;
  const pad16 = 24;
  
  canvasCtx.fillStyle = 'rgba(15, 23, 42, 0.75)';
  canvasCtx.beginPath();
  canvasCtx.roundRect(W - boxW - pad16, H - boxH - pad16, boxW, boxH, 8);
  canvasCtx.fill();
  
  // Text content configurations
  canvasCtx.fillStyle = '#ffffff';
  canvasCtx.textAlign = 'left';
  
  // Tracking Number Text
  canvasCtx.font = 'bold 22px "Inter", sans-serif';
  const trackText = 'TRACK: ' + (currentTrackingNo || 'WAITING SCAN...');
  canvasCtx.fillText(trackText, W - boxW - pad16 + 16, H - boxH - pad16 + 32);
  
  // Logistics Info
  canvasCtx.font = '16px "Inter", sans-serif';
  canvasCtx.fillStyle = '#cbd5e1';
  const logiText = 'LOGI: ' + (currentLogistics || 'Unknown');
  canvasCtx.fillText(logiText, W - boxW - pad16 + 16, H - boxH - pad16 + 58);
  
  // Date & Time stamp
  canvasCtx.fillStyle = '#94a3b8';
  canvasCtx.fillText(`${dateStr} ${timeStr}`, W - boxW - pad16 + 16, H - boxH - pad16 + 82);
  
  canvasCtx.restore();
}

// ============================================================
// Start recording video
// ============================================================
async function startRecording() {
  if (isRecording || !isExtensionEnabled) return;
  
  // Force Login: if no accessToken, show the big overlay and block recording
  if (!accessToken) {
    console.warn('No access token. Blocking recording start.');
    const overlay = document.getElementById('pr-login-overlay');
    if (overlay) overlay.style.display = 'flex';
    return;
  }
  
  // Prevent recording if no tracking number is found or it equals '--'
  if (!currentTrackingNo || currentTrackingNo === '--') {
    console.warn('Invalid tracking number (--). Aborting recording.');
    showUploadStatus('error', '❌ สแกนไม่พบข้อมูลแทร็คกิ้ง (ยกเลิกการอัดวิดีโอ)');
    return;
  }
  
  // Prepare status tracking
  recordedChunks = [];
  
  try {
    const canvasStream = canvasElement.captureStream(15); // 15 fps
    
    // Prefer MP4 (Chrome 120+), fallback to WebM for older browsers
    let mime = 'video/mp4; codecs=avc1.42E01E,opus';
    if (!MediaRecorder.isTypeSupported(mime)) mime = 'video/mp4';
    if (!MediaRecorder.isTypeSupported(mime)) mime = 'video/webm; codecs=vp9';
    if (!MediaRecorder.isTypeSupported(mime)) mime = 'video/webm; codecs=vp8';
    if (!MediaRecorder.isTypeSupported(mime)) mime = 'video/webm';
    
    console.log('[Packing Recorder] Recording with MIME:', mime);
    
    mediaRecorder = new MediaRecorder(canvasStream, {
      mimeType: mime,
      videoBitsPerSecond: 2500000 // 2.5 Mbps
    });
    
    mediaRecorder.ondataavailable = e => {
      if (e.data.size > 0) recordedChunks.push(e.data);
    };
    
    mediaRecorder.onstop = () => finalizeRecording();
    
    mediaRecorder.start(1000); // chunk every 1 sec
    
    isRecording = true;
    startTime = Date.now();
    
    // Update Panel UI
    if (recordBtn) {
      recordBtn.textContent = '⏹ หยุดบันทึก';
      recordBtn.className = 'pr-btn-record-big recording';
    }
    
    const recBadge = floatingPanel.querySelector('.pr-rec-badge');
    if (recBadge) recBadge.classList.remove('hidden');
    
    durationInterval = setInterval(updateDurationText, 1000);
    updateDurationText();
    
    showUploadStatus('normal', '🔴 กำลังบันทึกวิดีโอ...');
    console.log('Recording started successfully.');
    
  } catch (err) {
    console.error('Failed to start recording:', err);
    showUploadStatus('error', 'บันทึกไม่ได้: ' + err.message);
  }
}

// ============================================================
// Update UI Recording duration
// ============================================================
function updateDurationText() {
  if (!startTime || !durationBadge) return;
  const elapsed = Math.floor((Date.now() - startTime) / 1000);
  const m = String(Math.floor(elapsed / 60)).padStart(2, '0');
  const s = String(elapsed % 60).padStart(2, '0');
  durationBadge.textContent = `${m}:${s}`;
}

// ============================================================
// เฝ้ารอคำสั่งซื้อด้วย MutationObserver (เชื่อถือมากกว่า setInterval)
// ============================================================
function setupOrderObserver() {
  const observer = new MutationObserver(() => {
    // ล็อคเป้าเฉพาะตารางขวา "บันทึกการตรวจสอบ" (.scroll_list)
    // เพราะหน้านี้มีตาราง shipped_list สองอัน:
    //   ซ้าย: #currentScanList table.shipped_list (รายการ SKU ปัจจุบัน)
    //   ขวา: #shippedList table.shipped_list.scroll_list (ออเดอร์ที่ตรวจครบแล้ว)
    const row = document.querySelector('table.shipped_list.scroll_list tbody tr:not(.default_tr)');
    if (!row) return;
    
    const trackingSpan = row.querySelector('td:nth-child(2) span.f_gray');
    const orderCell = row.querySelector('td:nth-child(3)');
    if (!trackingSpan || !orderCell) return;
    
    const tracking = trackingSpan.textContent.trim().replace(/[\[\]]/g, '').trim();
    const orderNo = orderCell.textContent.trim();
    
    if (!tracking || !orderNo) return;
    
    // ป้องกัน trigger ซ้ำ: ถ้าเลขเดิมแล้วให้ข้าม
    if (tracking === currentTrackingNo && orderNo === currentOrderNo) return;
    
    console.log('[Packing Recorder] ✅ Order completion detected:', tracking, orderNo);
    
    currentTrackingNo = tracking;
    currentOrderNo = orderNo;
    
    if (trackingValEl) trackingValEl.textContent = tracking;
    
    // แสดง Popup เฉพาะตอนที่กำลังอัดวิดีโออยู่
    if (!isRecording) return;
    
    const popup = document.getElementById('pr-complete-popup');
    if (popup) popup.style.display = 'flex';
    
    // เล่นไฟล์เสียงจาก sounds/complete.mp4
    try {
      const audio = new Audio(chrome.runtime.getURL('sounds/complete.mp3'));
      audio.play();
    } catch (e) {
      console.warn('[Packing Recorder] Could not play sound:', e);
    }
  });
  
  // สังเกต document.body ทั้งหมด: subtree + childList + characterData
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
  
  console.log('[Packing Recorder] MutationObserver for order completion is active.');
}

// ============================================================
// Stop recording
// ============================================================
function stopRecording() {
  if (!mediaRecorder || !isRecording) return;
  
  isRecording = false;
  mediaRecorder.stop();
  
  clearInterval(durationInterval);
  // MutationObserver ทำงานตลอดเวลา ไม่ต้อง clear ที่นี่
  
  // ซ่อน popup ที่อาจค้างอยู่ก่อนสี่ปุ่ม
  const popup = document.getElementById('pr-complete-popup');
  if (popup) popup.style.display = 'none';
  
  // Update UI state
  if (recordBtn) {
    recordBtn.textContent = '▶ เริ่มบันทึก';
    recordBtn.className = 'pr-btn-record-big ready';
  }
  
  const recBadge = floatingPanel.querySelector('.pr-rec-badge');
  if (recBadge) recBadge.classList.add('hidden');
  
  showUploadStatus('normal', '⏹ หยุดบันทึกแล้ว กำลังเตรียมไฟล์...');
}

// ============================================================
// Process recorded chunks and initialize upload flow
// ============================================================
async function finalizeRecording() {
  const durationSec = Math.floor((Date.now() - startTime) / 1000);
  const recordTime = new Date(startTime);
  
  const trackingNo = currentTrackingNo || `TEMP_${Date.now()}`;
  const logistics = currentLogistics || 'Unknown';
  
  const yyyy = recordTime.getFullYear();
  const mm = String(recordTime.getMonth() + 1).padStart(2, '0');
  const dd = String(recordTime.getDate()).padStart(2, '0');
  
  const safeTracking = trackingNo.replace(/[^a-zA-Z0-9\-]/g, '_');
  const safeOrderNo = currentOrderNo ? currentOrderNo.replace(/[^a-zA-Z0-9\-]/g, '_') : '';
  const baseName = safeOrderNo ? `${safeTracking}_${safeOrderNo}` : safeTracking;
  
  // Detect format from what was actually recorded
  const recordedMime = mediaRecorder ? mediaRecorder.mimeType : 'video/webm';
  const isMP4 = recordedMime.includes('mp4');
  const fileExt = isMP4 ? 'mp4' : 'webm';
  const blobType = isMP4 ? 'video/mp4' : 'video/webm';
  
  const fileName = `${yyyy}_${mm}_${dd}_${baseName}.${fileExt}`;
  const blob = new Blob(recordedChunks, { type: blobType });
  
  console.log(`[Packing Recorder] Finalizing as ${fileExt.toUpperCase()} (${blobType}), size: ${(blob.size / 1024 / 1024).toFixed(2)}MB`);
  
  // Save local history log first
  const logEntry = {
    tracking_no: trackingNo,
    logistics: logistics,
    file_name: fileName,
    duration_seconds: durationSec,
    status: 'UPLOADING',
    drive_url: null
  };
  await saveLogToHistory(logEntry);
  
  // Start Upload to Drive
  await uploadFlow(blob, fileName, trackingNo, recordTime);
}

// ============================================================
// Drive Upload Flow
// ============================================================
async function uploadFlow(blob, fileName, trackingNo, recordTime) {
  showUploadStatus('uploading', `⏫ กำลังอัปโหลด ${fileName}...`);
  
  // Reload latest token
  await loadConfig();
  
  if (!accessToken) {
    await updateLogStatus(trackingNo, { status: 'FAILED' });
    showUploadStatus('error', '❌ ล้มเหลว: กรุณาลงชื่อเข้าใช้ Google Drive ใน Popup');
    return;
  }
  
  try {
    const yyyy = recordTime.getFullYear();
    const mm = String(recordTime.getMonth() + 1).padStart(2, '0');
    const dd = String(recordTime.getDate()).padStart(2, '0');
    
    // Ensure Date folder hierarchy
    const dateFolderId = await ensureDateFolderStructure(yyyy, mm, dd);
    
    // Execute Multipart File Upload
    const result = await uploadFileToDrive(blob, fileName, dateFolderId);
    
    await updateLogStatus(trackingNo, {
      status: 'SUCCESS',
      drive_file_id: result.id,
      drive_url: result.webViewLink
    });
    
    showUploadStatus('success', `✅ อัปโหลดสำเร็จ: ${trackingNo}`);
  } catch (err) {
    console.error('Google Drive Upload Failed:', err);
    await updateLogStatus(trackingNo, { status: 'FAILED' });
    
    // 1. สำรองข้อมูลลงเครื่องทันที (Auto Download)
    downloadBlobLocally(blob, fileName);
    
    // 2. ข้อมูลสำหรับปุ่ม Retry
    const failedData = { blob, fileName, trackingNo, recordTime };
    
    // Handle specific expired token error
    if (err.message.includes('AuthExpired')) {
      chrome.storage.local.remove(['access_token', 'user_info']); // Clear expired token
      showUploadStatus('error', `❌ เซสชันหมดอายุ! (เซฟลงเครื่องแล้ว: ${fileName})`, failedData);
    } else {
      showUploadStatus('error', `❌ อัปโหลดล้มเหลว! (เซฟลงเครื่องแล้ว: ${fileName})`, failedData);
    }
  }
}

// ============================================================
// Fallback: ดาวน์โหลดลงเครื่องกรณีอัปโหลดล้มเหลว
// ============================================================
function downloadBlobLocally(blob, fileName) {
  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 1000);
    console.log(`[Packing Recorder] บันทึกไฟล์ลงเครื่องเป็น Back-up สำเร็จ: ${fileName}`);
  } catch (err) {
    console.error('ไม่สามารถดาวน์โหลดไฟล์ลงเครื่องได้:', err);
  }
}

// ============================================================
// Google Drive Folder management API helpers
// ============================================================
async function ensureDateFolderStructure(yyyy, mm, dd) {
  const yearId = await getOrCreateFolder(yyyy, folderId);
  const monthId = await getOrCreateFolder(mm, yearId);
  const dayId = await getOrCreateFolder(dd, monthId);
  return dayId;
}

async function getOrCreateFolder(name, parentId) {
  const q = `name='${name}' and '${parentId}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`;
  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)&spaces=drive&includeItemsFromAllDrives=true&supportsAllDrives=true`;
  
  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  
  if (response.status === 401) throw new Error('AuthExpired');
  if (!response.ok) {
    const err = await response.json();
    throw new Error(`Drive folder query error: ${err.error?.message || response.statusText}`);
  }
  
  const data = await response.json();
  const files = data.files || [];
  
  if (files.length > 0) {
    return files[0].id;
  }
  
  // Create Folder if not exists
  const createResp = await fetch('https://www.googleapis.com/drive/v3/files?supportsAllDrives=true', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: name,
      mimeType: 'application/vnd.google-apps.folder',
      parents: [parentId]
    })
  });
  
  if (createResp.status === 401) throw new Error('AuthExpired');
  if (!createResp.ok) {
    const err = await createResp.json();
    throw new Error(`Drive folder creation error: ${err.error?.message || createResp.statusText}`);
  }
  
  const folder = await createResp.json();
  return folder.id;
}

async function uploadFileToDrive(blob, fileName, dateFolderId) {
  const metadata = {
    name: fileName,
    parents: [dateFolderId],
    mimeType: blob.type
  };
  
  const form = new FormData();
  form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  form.append('file', blob);
  
  const uploadUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink&supportsAllDrives=true';
  const resp = await fetch(uploadUrl, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` },
    body: form
  });
  
  if (resp.status === 401) throw new Error('AuthExpired');
  if (!resp.ok) {
    const err = await resp.json();
    throw new Error(`File upload error: ${err.error?.message || resp.statusText}`);
  }
  
  return await resp.json();
}

// ============================================================
// Show Alert notification in inline Status div
// ============================================================
function showUploadStatus(type, message, failedData = null) {
  const el = document.getElementById('pr-upload-status');
  if (!el) return;
  
  el.className = 'pr-upload-status show ' + type;
  
  if (type === 'uploading') {
    el.innerHTML = `<span class="pr-spinner"></span><span>${message}</span>`;
  } else if (failedData) {
    // ถ้ามี failedData แสดงปุ่ม Retry
    lastFailedUpload = failedData;
    el.innerHTML = `
      <span>${message}</span>
      <button id="pr-btn-retry-upload" style="margin-left:12px; padding:4px 10px; border-radius:6px; border:none; background:#fff; color:#ef4444; font-weight:bold; cursor:pointer; font-family:inherit; box-shadow:0 2px 5px rgba(0,0,0,0.2);">
        🔄 ลองใหม่
      </button>
    `;
    // ผูก Event ให้ปุ่ม Retry
    document.getElementById('pr-btn-retry-upload').addEventListener('click', () => {
      if (lastFailedUpload) {
        el.className = 'pr-upload-status'; // ซ่อน error ตัวเดิม
        uploadFlow(lastFailedUpload.blob, lastFailedUpload.fileName, lastFailedUpload.trackingNo, lastFailedUpload.recordTime);
      }
    });
  } else {
    el.innerHTML = `<span>${message}</span>`;
  }
  
  // Auto-hide success/error after 6 seconds (ยกเว้นกำลังอัปโหลด หรือ มีปุ่ม Retry)
  if (type !== 'uploading' && !failedData) {
    setTimeout(() => { el.className = 'pr-upload-status'; }, 6000);
  }
}

// ============================================================
// Inject Floating panel into BigSeller DOM
// ============================================================
function injectFloatingPanel() {
  if (document.getElementById('pr-floating-panel')) return;
  
  floatingPanel = document.createElement('div');
  floatingPanel.id = 'pr-floating-panel';
  floatingPanel.innerHTML = `
<!-- Toggle Button -->
<div class="pr-toggle-sidebar" id="pr-toggle-sidebar">&gt;</div>
<!-- Header -->
<div class="pr-header">
  <div class="pr-title">
    <img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="Logo" style="width:20px;height:20px;margin-right:6px;vertical-align:middle;border-radius:4px;">
    Packing Recorder
  </div>
</div>
<div class="pr-body">
  <!-- Big Pack Counter -->
  <div class="pr-counter-box">
    <div class="pr-counter-label">วันนี้แพ็คแล้ว</div>
    <div class="pr-counter-number" id="pr-pack-count">0</div>
    <div class="pr-counter-unit">ชิ้น</div>
  </div>
  <!-- Status Indicators -->
  <div class="pr-status-indicators">
    <div id="pr-ind-login" class="pr-indicator">
      <span class="pr-ind-dot grey"></span>
      <span class="pr-ind-label">ล็อกอิน: ตรวจสอบ...</span>
    </div>
    <div id="pr-ind-system" class="pr-indicator">
      <span class="pr-ind-dot grey"></span>
      <span class="pr-ind-label">ระบบ: ตรวจสอบ...</span>
    </div>
    <div id="pr-ind-camera" class="pr-indicator">
      <span class="pr-ind-dot grey"></span>
      <span class="pr-ind-label">กล้อง: ตรวจสอบ...</span>
    </div>
  </div>
  <!-- Camera Preview -->
  <div class="pr-preview-container">
    <video id="pr-video-hidden" autoplay playsinline muted></video>
    <canvas id="pr-canvas-preview" width="1280" height="720"></canvas>
    <div class="pr-placeholder">
      <span class="pr-placeholder-icon">📸</span>
      <span>กำลังโหลดกล้อง...</span>
    </div>
    <div class="pr-rec-badge hidden">
      <span class="pr-dot pulsing"></span>
      <span>REC</span>
      <span id="pr-duration">00:00</span>
    </div>
  </div>
  <!-- Upload Status (shown inline, replaces old status bar) -->
  <div class="pr-upload-status" id="pr-upload-status"></div>
  <!-- Tracking Big -->
  <div class="pr-tracking-big">
    <div class="pr-tracking-number" id="pr-tracking-val">-</div>
    <div class="pr-tracking-logistics" id="pr-logistics-val">รอสแกน...</div>
  </div>
  <!-- History -->
  <div class="pr-history-section">
    <div class="pr-history-header">
      <span>📋 ประวัติวันนี้</span>
      <span class="pr-history-badge" id="pr-history-count">0 รายการ</span>
    </div>
    <div id="pr-history-list">
      <div class="pr-history-empty">ยังไม่มีรายการวันนี้</div>
    </div>
  </div>
  <!-- Settings gear -->
  <button class="pr-btn-gear" id="pr-btn-settings">⚙️ ตั้งค่ากล้อง</button>
  <div class="pr-settings-panel" id="pr-settings-panel">
    <div class="pr-field">
      <label>เลือกกล้อง (Camera)</label>
      <select class="pr-select" id="pr-camera-select">
        <option value="">-- โหลดกล้อง --</option>
      </select>
    </div>
    <label class="pr-checkbox-row">
      <input type="checkbox" id="pr-auto-record-check" checked>
      <span>เริ่มอัดอัตโนมัติเมื่อสแกนพัสดุ</span>
    </label>
  </div>
</div>
  `;
  
  document.body.appendChild(floatingPanel);
  
  // Inject Login Warning Overlay
  if (!document.getElementById('pr-login-overlay')) {
    const overlay = document.createElement('div');
    overlay.id = 'pr-login-overlay';
    overlay.className = 'pr-login-overlay';
    overlay.innerHTML = `
      <h1>⚠️ คุณยังไม่ได้ล็อกอิน Google Drive</h1>
      <p>ระบบไม่สามารถอัปโหลดวิดีโอเข้าโฟลเดอร์ได้</p>
      <p>กรุณาคลิกที่ <b>ไอคอน Packing Recorder (มุมขวาบนของจอ)</b> เพื่อ Sign In ก่อน</p>
    `;
    document.body.appendChild(overlay);
  }

  // Inject Order Complete Popup
  if (!document.getElementById('pr-complete-popup')) {
    const popup = document.createElement('div');
    popup.id = 'pr-complete-popup';
    popup.className = 'pr-complete-popup';
    popup.innerHTML = `
      <div class="pr-popup-card">
        <div class="pr-popup-icon">✅</div>
        <h2>สแกนครบแล้ว!</h2>
        <p>วิดีโอกำลังบันทึกอยู่ กรุณาแพ็คสินค้าให้เรียบร้อย</p>
        <button class="pr-btn-pack-complete" id="pr-btn-pack-complete">รับทราบ</button>
      </div>
    `;
    document.body.appendChild(popup);
  }
  
  // Element caching
  streamVideo = document.getElementById('pr-video-hidden');
  canvasElement = document.getElementById('pr-canvas-preview');
  canvasCtx = canvasElement.getContext('2d');
  
  durationBadge = document.getElementById('pr-duration');
  trackingValEl = document.getElementById('pr-tracking-val');
  logisticsValEl = document.getElementById('pr-logistics-val');
  
  cameraSelect = document.getElementById('pr-camera-select');
  autoRecordCheck = document.getElementById('pr-auto-record-check');
  settingsPanel = document.getElementById('pr-settings-panel');
  
  // Hook Interactive Panel Events
  setupPanelEvents();
}

// ============================================================
// Setup Interactive Panel Events
// ============================================================
function setupPanelEvents() {
  // Toggle Sidebar
  const toggleBtn = document.getElementById('pr-toggle-sidebar');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      if (floatingPanel) {
        floatingPanel.classList.toggle('collapsed');
        toggleBtn.innerHTML = floatingPanel.classList.contains('collapsed') ? '&lt;' : '&gt;';
      }
    });
  }

  // Pack Complete Button — ปิด Popup เท่านั้น ไม่หยุดวิดีโอ
  const packCompleteBtn = document.getElementById('pr-btn-pack-complete');
  if (packCompleteBtn) {
    packCompleteBtn.addEventListener('click', () => {
      const popup = document.getElementById('pr-complete-popup');
      if (popup) popup.style.display = 'none';
      // วิดีโอยังอัดต่อ — จะหยุดเมื่อกด "ล้างข้อมูล & สแกนถัดไป" บน BigSeller เท่านั้น
    });
  }

  // Toggle Settings Panel
  const settingsBtn = document.getElementById('pr-btn-settings');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
      if (settingsPanel) settingsPanel.classList.toggle('open');
    });
  }
  
  // Select Camera Change
  if (cameraSelect) {
    cameraSelect.addEventListener('change', (e) => {
      initCamera(e.target.value);
    });
  }
  
  // Toggle Auto Record Checkbox
  if (autoRecordCheck) {
    autoRecordCheck.addEventListener('change', (e) => {
      autoRecordEnabled = e.target.checked;
      chrome.storage.local.set({ auto_record_enabled: autoRecordEnabled });
    });
  }
}

// ============================================================
// Update Pack Count
// ============================================================
async function updatePackCount() {
  const packCountEl = document.getElementById('pr-pack-count');
  if (!packCountEl) return;

  const data = await chrome.storage.local.get(['scan_history']);
  const history = data.scan_history || [];
  const todayStr = new Date().toISOString().split('T')[0];
  
  // Count SUCCESS items today
  const todaySuccessItems = history.filter(item => 
    item.created_at.startsWith(todayStr) && item.status === 'SUCCESS'
  );
  
  packCountEl.textContent = todaySuccessItems.length;
}

// ============================================================
// Update status indicator dots
// ============================================================
function updateStatusIndicators() {
  const loginEl = document.getElementById('pr-ind-login');
  const systemEl = document.getElementById('pr-ind-system');
  const cameraEl = document.getElementById('pr-ind-camera');
  
  if (loginEl) {
    const dot = loginEl.querySelector('.pr-ind-dot');
    const label = loginEl.querySelector('.pr-ind-label');
    if (dot && label) {
      dot.className = 'pr-ind-dot ' + (accessToken ? 'green' : 'orange');
      label.textContent = accessToken ? 'ล็อกอิน: พร้อม' : 'ล็อกอิน: ยังไม่ได้เชื่อมต่อ';
    }
  }
  
  if (systemEl) {
    const dot = systemEl.querySelector('.pr-ind-dot');
    const label = systemEl.querySelector('.pr-ind-label');
    if (dot && label) {
      dot.className = 'pr-ind-dot ' + (isExtensionEnabled ? 'green' : 'red');
      label.textContent = isExtensionEnabled ? 'ระบบ: พร้อม' : 'ระบบ: ปิดการทำงาน';
    }
  }

  if (cameraEl) {
    const dot = cameraEl.querySelector('.pr-ind-dot');
    const label = cameraEl.querySelector('.pr-ind-label');
    if (dot && label) {
      const cameraReady = streamVideo && streamVideo.srcObject && streamVideo.readyState >= 2;
      dot.className = 'pr-ind-dot ' + (cameraReady ? 'green' : 'red');
      label.textContent = cameraReady ? 'กล้อง: พร้อม' : 'กล้อง: ไม่ได้เชื่อมต่อ';
    }
  }
}

// ============================================================
// Render today's history in sidebar
// ============================================================
async function renderSidebarHistory() {
  const listEl = document.getElementById('pr-history-list');
  const countEl = document.getElementById('pr-history-count');
  if (!listEl) return;

  const data = await chrome.storage.local.get(['scan_history']);
  const history = data.scan_history || [];
  const todayStr = new Date().toISOString().split('T')[0];
  const todayItems = history.filter(item => item.created_at.startsWith(todayStr));

  if (countEl) countEl.textContent = `${todayItems.length} รายการ`;

  if (todayItems.length === 0) {
    listEl.innerHTML = '<div class="pr-history-empty">ยังไม่มีรายการวันนี้</div>';
    return;
  }

  listEl.innerHTML = todayItems.map(item => {
    const elapsedM = String(Math.floor(item.duration_seconds / 60)).padStart(2, '0');
    const elapsedS = String(item.duration_seconds % 60).padStart(2, '0');
    const timeLocal = new Date(item.created_at).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' });
    const statusIcon = item.status === 'SUCCESS' ? '✅' : item.status === 'UPLOADING' ? '⏫' : '❌';
    return `
      <div class="pr-hist-item">
        <div class="pr-hist-top">
          <span class="pr-hist-tracking">${item.tracking_no}</span>
          <span>${statusIcon}</span>
        </div>
        <div class="pr-hist-meta">${item.logistics} · ⏱ ${elapsedM}:${elapsedS} · ${timeLocal}</div>
        ${item.drive_url ? `<a href="${item.drive_url}" target="_blank" class="pr-hist-link">↗ เปิดใน Drive</a>` : ''}
      </div>
    `;
  }).join('');
}

// ============================================================
// Hook BigSeller UI scan inputs and clear buttons
// ============================================================
function hookBigSellerEvents() {
  console.log('Hooking BigSeller inputs and buttons...');

  // Event Delegation for scan inputs and clear buttons
  
  // 1. Hook the input for scanning
  document.body.addEventListener('keydown', (e) => {
    const input = e.target;
    const placeholder = input.placeholder || '';
    
    // Check if the input is explicitly the tracking input
    const isTrackingInput = placeholder.includes('แทร็คกิ้ง') || 
                            placeholder.includes('คำสั่งซื้อ') || 
                            placeholder.includes('พัสดุ') ||
                            placeholder.toLowerCase().includes('tracking');
                           
    if (isTrackingInput && e.key === 'Enter') {
      console.log('BigSeller barcode scan submitted.');
      
      if (!autoRecordEnabled || !isExtensionEnabled) return;
      
      // Delay slightly to let BigSeller update the tracking number or logistics on the screen
      setTimeout(async () => {
        scrapeTrackingAndLogistics();
        
        // If already recording, IGNORE this scan to prevent double records
        if (isRecording) {
          console.log('Already recording. Ignoring this tracking scan to prevent double-record.');
          return;
        }
        
        // Normal case: Start recording
        if (!accessToken) {
           const overlay = document.getElementById('pr-login-overlay');
           if (overlay) overlay.style.display = 'flex';
           return;
        }
        currentTrackingNo = '';
        currentOrderNo = '';
        currentLogistics = '';
        scrapeTrackingAndLogistics();
        startRecording();
      }, 500);
    }
  });

  // 2. Hook the "ล้างข้อมูล & สแกนถัดไป" Button to stop recording
  document.body.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    
    const btnText = btn.textContent.trim();
    if (btnText.includes('ล้างข้อมูล') && btnText.includes('สแกนถัดไป')) {
      console.log('Clicked "ล้างข้อมูล & สแกนถัดไป" button. Stopping video...');
      if (isRecording) {
        stopRecording();
      }
    }
  });
  
  // ตั้ง MutationObserver เพื่อตรวจจับการแพ็คสำเร็จจากตาราง shipped_list
  setupOrderObserver();
}

// ============================================================
// Main Bootstrapping
// ============================================================
(async () => {
  // URL Restriction — manifest.json handles this now, but keep as safety net for mock page
  const currentUrl = window.location.href;
  if (!currentUrl.includes('/web/order/scanToInspection.htm') && !currentUrl.includes('mock_bigseller.html')) {
    return;
  }

  // Load configuration first
  await loadConfig();
  
  // Restore configs from storage
  const storage = await chrome.storage.local.get(['selected_device_id', 'auto_record_enabled', 'extension_enabled']);
  if (storage.selected_device_id) activeDeviceId = storage.selected_device_id;
  if (storage.hasOwnProperty('auto_record_enabled')) autoRecordEnabled = storage.auto_record_enabled;
  if (storage.hasOwnProperty('extension_enabled')) isExtensionEnabled = storage.extension_enabled;
  
  // Inject CSS styles and construct sidebar
  injectFloatingPanel();
  
  if (autoRecordCheck) autoRecordCheck.checked = autoRecordEnabled;
  
  // Start drawing canvas overlays
  drawCanvasLoop();
  
  // Request webcam & configure camera settings
  await initCamera(activeDeviceId);
  
  // Update status dots after camera init
  updateStatusIndicators();
  
  // Retry updating indicators in case camera takes longer to be ready
  setTimeout(updateStatusIndicators, 2000);

  // Update pack count & history
  await updatePackCount();
  await renderSidebarHistory();
  
  // Hook DOM observers and events
  hookBigSellerEvents();
  
  // Listen for messages from popup (toggle)
  chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'SET_ENABLED') {
      isExtensionEnabled = request.enabled;
      if (!isExtensionEnabled && isRecording) stopRecording();
    }
  });

  // Listen for storage changes to hot-reload configs
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
      if (changes.access_token) {
        accessToken = changes.access_token.newValue;
        updateStatusIndicators();
        // Hide login overlay if token becomes available
        if (accessToken) {
          const overlay = document.getElementById('pr-login-overlay');
          if (overlay) overlay.style.display = 'none';
        }
      }
      if (changes.gcp_client_id) clientId = changes.gcp_client_id.newValue;
      if (changes.gcp_folder_id) folderId = changes.gcp_folder_id.newValue;
      if (changes.extension_enabled) isExtensionEnabled = changes.extension_enabled.newValue;
      if (changes.scan_history) {
        renderSidebarHistory();
        updatePackCount();
      }
    }
  });
})();
