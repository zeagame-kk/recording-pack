// ============================================================
//  BACKGROUND SERVICE WORKER
//  สคริปต์นี้ทำงานเบื้องหลังตลอดเวลา คอยจัดการ OAuth 2.0 (Login/Logout)
//  และจัดการ Extension settings (Client ID, Folder ID)
// ============================================================

// Default configs (ค่าเริ่มต้นหากผู้ใช้ยังไม่ได้ตั้งค่า)
const DEFAULT_CLIENT_ID = '277747309803-db3jj7o5v9860ic6prfs6u801l1cao0b.apps.googleusercontent.com';
const DEFAULT_FOLDER_ID = '1uKbeRbBONdq1aFMwIs94yfd4WXwG_fCj';

// On install, setup defaults (เมื่อติดตั้ง Extension ให้เซ็ตค่าเริ่มต้น)
chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({ 
    gcp_client_id: DEFAULT_CLIENT_ID,
    gcp_folder_id: DEFAULT_FOLDER_ID 
  });
  console.log('Packing Recorder Extension installed and initialized.');
});

// Listener for messages (รับคำสั่งจาก popup.js หรือ content.js)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'GET_SETTINGS') {
    chrome.storage.local.get(['access_token', 'user_info']).then(settings => {
      sendResponse({ 
        success: true, 
        settings: {
          ...settings,
          gcp_client_id: DEFAULT_CLIENT_ID,
          gcp_folder_id: DEFAULT_FOLDER_ID
        }
      });
    });
    return true; // keep channel open for async response
  }

  if (request.action === 'SAVE_SETTINGS') {
    chrome.storage.local.set({
      gcp_client_id: request.clientId,
      gcp_folder_id: request.folderId
    }).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === 'START_AUTH') {
    startOAuthFlow(request.clientId).then(tokenInfo => {
      sendResponse({ success: true, ...tokenInfo });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }

  if (request.action === 'LOGOUT') {
    chrome.storage.local.remove(['access_token', 'user_info']).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
});

// OAuth 2.0 Flow using launchWebAuthFlow
async function startOAuthFlow(clientId) {
  const redirectUrl = chrome.identity.getRedirectURL(); // e.g. https://<ext-id>.chromiumapp.org/
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` + 
    `client_id=${encodeURIComponent(clientId)}&` +
    `response_type=token&` +
    `redirect_uri=${encodeURIComponent(redirectUrl)}&` +
    `scope=${encodeURIComponent('https://www.googleapis.com/auth/drive.file')}&` +
    `prompt=consent`;

  console.log('Starting auth flow with URL:', authUrl);

  return new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true
    }, async (redirectedTo) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      if (!redirectedTo) {
        reject(new Error('User cancelled or no redirect URL received.'));
        return;
      }

      // Parse token from hash fragment
      const url = new URL(redirectedTo);
      const params = new URLSearchParams(url.hash.substring(1));
      const accessToken = params.get('access_token');
      const expiresIn = params.get('expires_in');

      if (!accessToken) {
        reject(new Error('Access token not found in auth response.'));
        return;
      }

      // Optionally get user info (email) from Google API
      let email = 'Google Account';
      try {
        const profileResp = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        if (profileResp.ok) {
          const profile = await profileResp.json();
          email = profile.email || email;
        }
      } catch (e) {
        console.warn('Failed to fetch user profile:', e);
      }

      const tokenData = {
        access_token: accessToken,
        user_info: email,
        expires_at: Date.now() + (parseInt(expiresIn) * 1000)
      };

      await chrome.storage.local.set(tokenData);
      resolve(tokenData);
    });
  });
}
