// ============================================================
//  PACKING RECORDER CONTENT SCRIPT
// ============================================================

// ============================================================
// State Variables
// ============================================================
let accessToken = null;
let clientId = null;
let folderId = null;
let autoRecordEnabled = true;
let isExtensionEnabled = true;

let mediaRecorder = null;
let recordedChunks = [];
let isRecording = false;
let isScanLocked = false; // บล็อกการสแกนและย้าย Cursor ขณะ Pop-up แสดงผล
let lastFrameTime = 0;

// เก็บข้อมูลไฟล์ที่อัปโหลดไม่ผ่านไว้ใน RAM เพื่อให้กด Retry ได้
let lastFailedUpload = null;

let startTime = null;
let durationInterval = null;
let animationFrameId = null;

let streamVideo = null;
let canvasElement = null;
let canvasCtx = null;
let activeDeviceId = null;

let currentTrackingNo = '';
let currentOrderNo = '';
let currentLogistics = '';
let orderCheckInterval = null;

// Track active uploads for beforeunload warning
window.activeUploads = 0;

// ดักจับการปิดหน้าเว็บ (Prevent Unload)
window.addEventListener('beforeunload', (e) => {
  if (isRecording || window.activeUploads > 0) {
    e.preventDefault();
    e.returnValue = ''; // บังคับให้เบราว์เซอร์แสดงแจ้งเตือน
  }
});

// ============================================================
// UI Elements
// ============================================================
let floatingPanel = null;
let durationBadge = null;
let trackingValEl = null;
let logisticsValEl = null;
let cameraSelect = null;
let autoRecordCheck = null;
let recordBtn = null;
let settingsPanel = null;

// ============================================================
// Storage Operation Queue — ป้องกัน race condition ที่เกิดจาก
// การ read-modify-write แบบ async พร้อมกัน (Bug #1 fix)
// เหตุ: ตัวนับวนรอบ ~95 เพราะ saveLogToHistory และ updateLogStatus
// อ่าน history คนละ snapshot แล้วเขียนทับกัน
// ============================================================
let _storageQueue = Promise.resolve();

function queueStorageOp(operation) {
  _storageQueue = _storageQueue.then(operation).catch(err => {
    console.error('[Packing Recorder] Storage queue error:', err);
  });
  return _storageQueue;
}

// ============================================================
// IndexedDB replacement - Sync storage history helper
// ============================================================
async function saveLogToHistory(logEntry) {
  return queueStorageOp(async () => {
    const data = await chrome.storage.local.get(['scan_history']);
    let history = data.scan_history || [];
    
    // Insert at beginning
    history.unshift({
      id: Date.now(),
      created_at: new Date().toISOString(),
      ...logEntry
    });

    // Limit to 500 entries and clean up entries older than 3 days
    // (Bug #1 fix: เพิ่ม cap จาก 100 → 500 เพื่อรองรับสูงเกิน 100 ชิ้น/วัน)
    const now = Date.now();
    const threeDays = 3 * 24 * 60 * 60 * 1000;
    history = history.filter(item => {
      const age = now - new Date(item.created_at).getTime();
      return age < threeDays;
    }).slice(0, 500);

    await chrome.storage.local.set({ scan_history: history });
  });
}

async function updateLogStatus(trackingNo, updates) {
  return queueStorageOp(async () => {
    const data = await chrome.storage.local.get(['scan_history']);
    let history = data.scan_history || [];
    
    const index = history.findIndex(item => item.tracking_no === trackingNo);
    if (index !== -1) {
      history[index] = { ...history[index], ...updates };
      await chrome.storage.local.set({ scan_history: history });
    }
  });
}

// ============================================================
// IndexedDB — Persistent Failed Upload Queue (Bug #2 fix)
// ============================================================
const FAILED_DB_NAME = 'PackingRecorderFailedUploads';
const FAILED_DB_VERSION = 1;
const FAILED_STORE_NAME = 'pending_uploads';

function openFailedUploadsDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(FAILED_DB_NAME, FAILED_DB_VERSION);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(FAILED_STORE_NAME)) {
        db.createObjectStore(FAILED_STORE_NAME, { keyPath: 'trackingNo' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function saveBlobToRetryQueue(blob, fileName, trackingNo, recordTime) {
  try {
    const db = await openFailedUploadsDB();
    const tx = db.transaction(FAILED_STORE_NAME, 'readwrite');
    const store = tx.objectStore(FAILED_STORE_NAME);
    store.put({
      trackingNo,
      fileName,
      recordTime: recordTime.toISOString(),
      blob,
      savedAt: new Date().toISOString()
    });
    await new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
    db.close();
    console.log(`[Packing Recorder] Blob saved to IndexedDB retry queue: ${trackingNo}`);
  } catch (err) {
    console.error('[Packing Recorder] Failed to save blob to IndexedDB:', err);
  }
}

async function removeBlobFromRetryQueue(trackingNo) {
  try {
    const db = await openFailedUploadsDB();
    const tx = db.transaction(FAILED_STORE_NAME, 'readwrite');
    tx.objectStore(FAILED_STORE_NAME).delete(trackingNo);
    await new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch (err) {
    console.error('[Packing Recorder] Failed to remove blob from IndexedDB:', err);
  }
}

async function loadRetryQueueFromDB() {
  try {
    const db = await openFailedUploadsDB();
    const tx = db.transaction(FAILED_STORE_NAME, 'readonly');
    const store = tx.objectStore(FAILED_STORE_NAME);
    const allItems = await new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    db.close();

    // Auto-cleanup entries older than 7 days
    const sevenDays = 7 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    const validItems = [];
    
    for (const item of allItems) {
      const age = now - new Date(item.savedAt).getTime();
      if (age > sevenDays) {
        await removeBlobFromRetryQueue(item.trackingNo);
      } else {
        validItems.push(item);
      }
    }

    // Restore to window.failedBlobs for UI retry compatibility
    window.failedBlobs = window.failedBlobs || {};
    for (const item of validItems) {
      window.failedBlobs[item.trackingNo] = {
        blob: item.blob,
        fileName: item.fileName,
        trackingNo: item.trackingNo,
        recordTime: new Date(item.recordTime)
      };
    }

    console.log(`[Packing Recorder] Restored ${validItems.length} pending uploads from IndexedDB`);
    return validItems.length;
  } catch (err) {
    console.error('[Packing Recorder] Failed to load retry queue:', err);
    return 0;
  }
}

// ============================================================
// Proactive Token Expiry Watchdog (Bug #6 fix)
// ============================================================
let tokenWatchdogInterval = null;

function startTokenWatchdog() {
  // ตรวจทุก 15 นาที
  tokenWatchdogInterval = setInterval(async () => {
    const data = await chrome.storage.local.get(['expires_at', 'access_token']);
    
    if (!data.access_token) return; // ยังไม่เคยล็อกอิน ข้าม

    const now = Date.now();
    const expiresAt = data.expires_at || 0;
    const remainingMs = expiresAt - now;
    const remainingMin = Math.floor(remainingMs / 60000);

    if (remainingMs <= 0) {
      // Token หมดอายุแล้ว
      console.warn('[Packing Recorder] ⚠️ Token expired!');
      accessToken = null;
      chrome.storage.local.remove(['access_token', 'user_info']);
      showLoginOverlay();
      updateStatusIndicators();
      showUploadStatus('error', '🔴 เซสชัน Google Drive หมดอายุแล้ว กรุณาลงชื่อเข้าใช้ใหม่ก่อนสแกนพัสดุ');
    } else if (remainingMs < 10 * 60 * 1000) {
      // Token เหลือน้อยกว่า 10 นาที
      console.warn(`[Packing Recorder] ⚠️ Token expiring in ${remainingMin} minutes.`);
      showUploadStatus('error', `⚠️ เซสชันจะหมดอายุใน ${remainingMin} นาที กรุณาลงชื่อเข้าใช้ Google Drive ใหม่`);
    }
  }, 15 * 60 * 1000); // ทุก 15 นาที

  // ตรวจครั้งแรกทันที (เผื่อเปิดหน้ามาตอน Token หมดอายุแล้ว)
  setTimeout(async () => {
    const data = await chrome.storage.local.get(['expires_at', 'access_token']);
    if (data.access_token && data.expires_at) {
      const remaining = data.expires_at - Date.now();
      if (remaining <= 0) {
        accessToken = null;
        chrome.storage.local.remove(['access_token', 'user_info']);
        showLoginOverlay();
        updateStatusIndicators();
      }
    }
  }, 5000);
}

// ============================================================
// Initialize configurations from chrome storage
// ============================================================
async function loadConfig() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'GET_SETTINGS' }, (response) => {
      if (response && response.success) {
        const settings = response.settings;
        clientId = settings.gcp_client_id;
        folderId = settings.gcp_folder_id;
        accessToken = settings.access_token;
      }
      resolve();
    });
  });
}

function showLoginOverlay() {
  const overlay = document.getElementById('pr-login-overlay');
  if (overlay) overlay.style.display = 'flex';
}

function hideLoginOverlay() {
  const overlay = document.getElementById('pr-login-overlay');
  if (overlay) overlay.style.display = 'none';
}

async function validateAuthTokenOnBoot() {
  await loadConfig();
  if (!accessToken) {
    console.warn('[Packing Recorder] No access token found on boot.');
    showLoginOverlay();
    return false;
  }

  // Validate token with Google TokenInfo API
  try {
    const resp = await fetch(`https://www.googleapis.com/oauth2/v3/tokeninfo?access_token=${accessToken}`);
    if (!resp.ok) {
      throw new Error(`Token validation failed with HTTP ${resp.status}`);
    }
    console.log('[Packing Recorder] ✅ Access token is valid.');
    hideLoginOverlay();
    updateStatusIndicators();
    return true;
  } catch (err) {
    console.warn('[Packing Recorder] Auth token is invalid or expired:', err);
    chrome.storage.local.remove(['access_token', 'user_info']);
    accessToken = null;
    showLoginOverlay();
    updateStatusIndicators();
    return false;
  }
}

// ============================================================
// Scrape Tracking Number and Logistics from DOM
// ============================================================
function scrapeTrackingAndLogistics() {
  // 1. Scrape Tracking No from <span class="tackingNo">
  const trackingEl = document.querySelector('span.tackingNo');
  if (trackingEl) {
    const txt = trackingEl.textContent.trim();
    if (txt && txt !== currentTrackingNo) {
      currentTrackingNo = txt;
      if (trackingValEl) trackingValEl.textContent = txt;
    }
  }

  // 2. Scrape Logistics from <span class="shipMethod"> or fallback DOM text
  const shipMethodEl = document.querySelector('span.shipMethod');
  if (shipMethodEl) {
    const txt = shipMethodEl.textContent.trim();
    if (txt && txt !== currentLogistics) {
      currentLogistics = txt;
      if (logisticsValEl) logisticsValEl.textContent = txt;
    }
  } else {
    // Fallback: Scrape Logistics from DOM containing "โลจิสติกส์"
    const elements = document.querySelectorAll('*');
    for (const el of elements) {
      if (el.children.length === 0 && el.textContent.includes('โลจิสติกส์')) {
        const parentTxt = el.parentElement ? el.parentElement.textContent.trim() : el.textContent.trim();
        const match = parentTxt.match(/โลจิสติกส์\s*(.*)/i);
        if (match && match[1]) {
          const logi = match[1].trim();
          if (logi && logi !== currentLogistics) {
            currentLogistics = logi;
            if (logisticsValEl) logisticsValEl.textContent = logi;
          }
          break;
        }
      }
    }
  }
}

// ============================================================
// Start camera stream
// ============================================================
// ============================================================
// Start camera stream (with Fallback & Auto-Recovery)
// ============================================================
async function initCamera(deviceId = null) {
  if (streamVideo && streamVideo.srcObject) {
    streamVideo.srcObject.getTracks().forEach(t => t.stop());
  }

  const baseConstraints = {
    video: {
      width: { ideal: 1280 },
      height: { ideal: 720 },
      frameRate: { ideal: 15 }
    },
    audio: false
  };

  let stream = null;
  let usedDeviceId = deviceId;

  // Try 1: Exact device ID if provided
  if (deviceId) {
    try {
      const strictConstraints = {
        video: { ...baseConstraints.video, deviceId: { exact: deviceId } },
        audio: false
      };
      stream = await navigator.mediaDevices.getUserMedia(strictConstraints);
    } catch (err) {
      console.warn(`Exact camera init failed for device ID (${deviceId}), trying fallback...`, err);
    }
  }

  // Try 2: Ideal device ID or standard constraints if exact failed
  if (!stream) {
    try {
      const fallbackConstraints = {
        video: { ...baseConstraints.video },
        audio: false
      };
      if (deviceId) fallbackConstraints.video.deviceId = { ideal: deviceId };
      stream = await navigator.mediaDevices.getUserMedia(fallbackConstraints);
      usedDeviceId = stream.getVideoTracks()[0]?.getSettings()?.deviceId || deviceId;
    } catch (err) {
      // Try 3: Basic video true constraint
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        usedDeviceId = stream.getVideoTracks()[0]?.getSettings()?.deviceId || null;
      } catch (finalErr) {
        console.error('All camera init attempts failed:', finalErr);
        showUploadStatus('error', 'เปิดกล้องไม่ได้: ' + finalErr.message);
        showCameraErrorPlaceholder(finalErr.message);
        return;
      }
    }
  }

  try {
    streamVideo.srcObject = stream;
    await streamVideo.play();
    
    // Add track event listeners for disconnect/mute handling
    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      videoTrack.onended = () => {
        console.warn('Camera video track ended unexpectedly!');
        showCameraErrorPlaceholder('สายกล้องหลุดหรือการเชื่อมต่อขาดหาย');
      };
      videoTrack.onmute = () => {
        console.warn('Camera video track muted');
      };
      videoTrack.onunmute = () => {
        console.log('Camera video track unmuted');
      };
    }
    
    // Hide camera placeholder overlay
    const placeholder = floatingPanel ? floatingPanel.querySelector('.pr-placeholder') : null;
    if (placeholder) placeholder.classList.add('hidden');
    
    // Save working device ID
    if (usedDeviceId) {
      activeDeviceId = usedDeviceId;
      await chrome.storage.local.set({ selected_device_id: usedDeviceId });
    }

    // Populate camera list
    populateCameraList();
    updateStatusIndicators();
  } catch (err) {
    console.error('Camera play error:', err);
    showCameraErrorPlaceholder(err.message);
  }
}

function showCameraErrorPlaceholder(msg) {
  const placeholder = floatingPanel ? floatingPanel.querySelector('.pr-placeholder') : null;
  if (placeholder) {
    placeholder.classList.remove('hidden');
    placeholder.innerHTML = `
      <span class="pr-placeholder-icon">❌</span>
      <span>เปิดกล้องไม่ได้: ${msg || 'สิทธิ์กล้องถูกปฏิเสธ'}</span>
      <button id="pr-btn-retry-camera" style="margin-top:8px; padding:4px 12px; border-radius:6px; border:none; background:#10b981; color:#fff; font-weight:bold; cursor:pointer; font-family:inherit; box-shadow:0 2px 5px rgba(0,0,0,0.2);">
        🔄 ลองเชื่อมต่อกล้องใหม่
      </button>
    `;
    const retryBtn = placeholder.querySelector('#pr-btn-retry-camera');
    if (retryBtn) {
      retryBtn.addEventListener('click', () => {
        initCamera(activeDeviceId);
      });
    }
  }
}

// ============================================================
// Populate Camera Selector Dropdown
// ============================================================
async function populateCameraList() {
  if (!cameraSelect) return;
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const videoDevices = devices.filter(d => d.kind === 'videoinput');
    
    cameraSelect.innerHTML = '';
    videoDevices.forEach(d => {
      const opt = document.createElement('option');
      opt.value = d.deviceId;
      opt.textContent = d.label || `Camera ${cameraSelect.length + 1}`;
      if (d.deviceId === activeDeviceId) {
        opt.selected = true;
      }
      cameraSelect.appendChild(opt);
    });
  } catch (e) {
    console.warn('Failed to enumerate video devices:', e);
  }
}

// ============================================================
// Drawing Loop: Redraw camera frames to Canvas & Dual-Ticker Engine
// ============================================================
let lastFrameTimestamp = 0;
let fallbackIntervalId = null;

function renderCanvasFrame() {
  const now = Date.now();
  // Prevent double rendering if drawn less than 30ms ago
  if (now - lastFrameTimestamp < 30) return;
  lastFrameTimestamp = now;

  if (streamVideo && streamVideo.readyState >= 2) {
    // Prevent browser energy saver from pausing the video
    if (streamVideo.paused) {
      streamVideo.play().catch(e => console.warn('Could not force play video:', e));
    }
    
    // ALWAYS draw live camera video feed onto Canvas
    canvasCtx.drawImage(streamVideo, 0, 0, canvasElement.width, canvasElement.height);

    if (isRecording) {
      drawWatermark();
    } else {
      drawStandbyOverlay();
    }
  }
}

function drawCanvasLoop() {
  renderCanvasFrame();
  animationFrameId = requestAnimationFrame(drawCanvasLoop);
}

// Fallback interval (15 FPS / 66ms) for Chrome Energy Saver & Tab Backgrounding
if (!fallbackIntervalId) {
  fallbackIntervalId = setInterval(() => {
    // If rAF hasn't fired for >60ms (tab backgrounded or energy saver active), draw via interval
    if (Date.now() - lastFrameTimestamp >= 60) {
      renderCanvasFrame();
    }
  }, 66);
}

// Standby overlay badge when not recording
function drawStandbyOverlay() {
  const W = canvasElement.width;
  const H = canvasElement.height;

  canvasCtx.save();
  
  // Translucent badge in top left corner
  const badgeW = 210;
  const badgeH = 40;
  canvasCtx.fillStyle = 'rgba(15, 23, 42, 0.75)';
  canvasCtx.beginPath();
  if (canvasCtx.roundRect) {
    canvasCtx.roundRect(16, 16, badgeW, badgeH, 6);
  } else {
    canvasCtx.rect(16, 16, badgeW, badgeH);
  }
  canvasCtx.fill();

  // Green Indicator Dot
  canvasCtx.fillStyle = '#10b981';
  canvasCtx.beginPath();
  canvasCtx.arc(36, 36, 6, 0, 2 * Math.PI);
  canvasCtx.fill();

  // Text: "กล้องพร้อมใช้งาน"
  canvasCtx.fillStyle = '#ffffff';
  canvasCtx.font = 'bold 16px "Inter", sans-serif';
  canvasCtx.textAlign = 'left';
  canvasCtx.textBaseline = 'middle';
  canvasCtx.fillText('กล้องพร้อมใช้งาน', 52, 36);

  canvasCtx.restore();
}

// ============================================================
// Draw Watermark (Burn-in metadata) on recording canvas
// ============================================================
function drawWatermark() {
  // Scrape tracking info dynamically in loop so it updates during the video
  scrapeTrackingAndLogistics();

  const W = canvasElement.width;
  const H = canvasElement.height;
  
  // Format Date & Time: YYYY-MM-DD HH:MM:SS
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const dateStr = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
  const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  
  canvasCtx.save();
  
  // Outer Border Overlay (Blinking Red while recording)
  if (isRecording) {
    canvasCtx.strokeStyle = 'rgba(239, 68, 68, 0.85)';
    canvasCtx.lineWidth = 8;
    canvasCtx.strokeRect(4, 4, W - 8, H - 8);
    
    // Blinking effect for recording indicator in corner
    if (Math.floor(Date.now() / 500) % 2 === 0) {
      canvasCtx.fillStyle = '#ef4444';
      canvasCtx.beginPath();
      canvasCtx.arc(35, 35, 10, 0, 2 * Math.PI);
      canvasCtx.fill();
    }
  }

  // Draw Translucent overlay box for text in the bottom right corner
  const boxW = 420;
  const boxH = 100;
  const pad16 = 24;
  
  canvasCtx.fillStyle = 'rgba(15, 23, 42, 0.75)';
  canvasCtx.beginPath();
  if (canvasCtx.roundRect) {
    canvasCtx.roundRect(W - boxW - pad16, H - boxH - pad16, boxW, boxH, 8);
  } else {
    canvasCtx.rect(W - boxW - pad16, H - boxH - pad16, boxW, boxH);
  }
  canvasCtx.fill();
  
  // Text content configurations
  canvasCtx.fillStyle = '#ffffff';
  canvasCtx.textAlign = 'left';
  
  // Tracking Number Text
  canvasCtx.font = 'bold 22px "Inter", sans-serif';
  const trackText = 'TRACK: ' + (currentTrackingNo || 'WAITING SCAN...');
  canvasCtx.fillText(trackText, W - boxW - pad16 + 16, H - boxH - pad16 + 32);
  
  // Logistics Info
  canvasCtx.font = '16px "Inter", sans-serif';
  canvasCtx.fillStyle = '#cbd5e1';
  const logiText = 'LOGI: ' + (currentLogistics || 'Unknown');
  canvasCtx.fillText(logiText, W - boxW - pad16 + 16, H - boxH - pad16 + 58);
  
  // Date & Time stamp
  canvasCtx.fillStyle = '#94a3b8';
  canvasCtx.fillText(`${dateStr} ${timeStr}`, W - boxW - pad16 + 16, H - boxH - pad16 + 82);
  
  canvasCtx.restore();
}

// ============================================================
// Start recording video
// ============================================================
async function startRecording() {
  if (isRecording || !isExtensionEnabled) return;
  
  // Force Login: if no accessToken, show the big overlay and block recording
  if (!accessToken) {
    console.warn('No access token. Blocking recording start.');
    const overlay = document.getElementById('pr-login-overlay');
    if (overlay) overlay.style.display = 'flex';
    return;
  }
  
  // Prevent recording if no logistics info is found or it equals '--'
  if (!currentLogistics || currentLogistics === '--') {
    console.warn('Invalid logistics (--). Aborting recording.');
    showUploadStatus('error', '❌ สแกนไม่พบข้อมูลโลจิสติกส์ (ยกเลิกการอัดวิดีโอ)');
    return;
  }
  
  // Prepare status tracking
  recordedChunks = [];
  
  try {
    const canvasStream = canvasElement.captureStream(15); // 15 fps
    
    // Prefer MP4 (Chrome 120+), fallback to WebM for older browsers
    let mime = 'video/mp4; codecs=avc1.42E01E,opus';
    if (!MediaRecorder.isTypeSupported(mime)) mime = 'video/mp4';
    if (!MediaRecorder.isTypeSupported(mime)) mime = 'video/webm; codecs=vp9';
    if (!MediaRecorder.isTypeSupported(mime)) mime = 'video/webm; codecs=vp8';
    if (!MediaRecorder.isTypeSupported(mime)) mime = 'video/webm';
    
    console.log('[Packing Recorder] Recording with MIME:', mime);
    
    mediaRecorder = new MediaRecorder(canvasStream, {
      mimeType: mime,
      videoBitsPerSecond: 2500000 // 2.5 Mbps
    });
    
    mediaRecorder.ondataavailable = e => {
      if (e.data.size > 0) recordedChunks.push(e.data);
    };
    
    mediaRecorder.onstop = () => finalizeRecording();
    
    mediaRecorder.start(1000); // chunk every 1 sec
    
    isRecording = true;
    startTime = Date.now();
    
    // Update Panel UI
    if (recordBtn) {
      recordBtn.textContent = '⏹ หยุดบันทึก';
      recordBtn.className = 'pr-btn-record-big recording';
    }
    
    const recBadge = floatingPanel.querySelector('.pr-rec-badge');
    if (recBadge) recBadge.classList.remove('hidden');
    
    durationInterval = setInterval(updateDurationText, 1000);
    updateDurationText();
    
    showUploadStatus('normal', '🔴 กำลังบันทึกวิดีโอ...');
    console.log('Recording started successfully.');
    
  } catch (err) {
    console.error('Failed to start recording:', err);
    showUploadStatus('error', 'บันทึกไม่ได้: ' + err.message);
  }
}

// ============================================================
// Update UI Recording duration
// ============================================================
function updateDurationText() {
  if (!startTime || !durationBadge) return;
  const elapsed = Math.floor((Date.now() - startTime) / 1000);
  const m = String(Math.floor(elapsed / 60)).padStart(2, '0');
  const s = String(elapsed % 60).padStart(2, '0');
  durationBadge.textContent = `${m}:${s}`;
}

// ============================================================
// เฝ้ารอคำสั่งซื้อด้วย MutationObserver (เชื่อถือมากกว่า setInterval)
// ============================================================
function setupOrderObserver() {
  const observer = new MutationObserver(() => {
    // ล็อคเป้าเฉพาะตารางขวา "บันทึกการตรวจสอบ" (.scroll_list)
    // เพราะหน้านี้มีตาราง shipped_list สองอัน:
    //   ซ้าย: #currentScanList table.shipped_list (รายการ SKU ปัจจุบัน)
    //   ขวา: #shippedList table.shipped_list.scroll_list (ออเดอร์ที่ตรวจครบแล้ว)
    const row = document.querySelector('table.shipped_list.scroll_list tbody tr:not(.default_tr)');
    if (!row) return;
    
    const trackingSpan = row.querySelector('td:nth-child(2) span.f_gray');
    const orderCell = row.querySelector('td:nth-child(3)');
    if (!trackingSpan || !orderCell) return;
    
    const tracking = trackingSpan.textContent.trim().replace(/[\[\]]/g, '').trim();
    const orderNo = orderCell.textContent.trim();
    
    if (!tracking || !orderNo) return;
    
    // ป้องกัน trigger ซ้ำ: ถ้าเลขเดิมแล้วให้ข้าม
    if (tracking === currentTrackingNo && orderNo === currentOrderNo) return;
    
    console.log('[Packing Recorder] ✅ Order completion detected:', tracking, orderNo);
    
    currentTrackingNo = tracking;
    currentOrderNo = orderNo;
    
    if (trackingValEl) trackingValEl.textContent = tracking;
    
    // แสดง Popup เฉพาะตอนที่กำลังอัดวิดีโออยู่
    if (!isRecording) return;
    
    // เปิดการล็อคการสแกน และปลด Focus ออกจากช่องป้อนข้อมูล
    isScanLocked = true;
    if (document.activeElement && typeof document.activeElement.blur === 'function') {
      document.activeElement.blur();
    }
    
    // ตั้งใจนำ Safety Fallback ออกตามความต้องการ เพื่อให้พนักงานบังคับต้องกด "รับทราบ" เท่านั้น
    
    const popup = document.getElementById('pr-complete-popup');
    if (popup) popup.style.display = 'flex';
    
    // เล่นไฟล์เสียงจาก sounds/complete.mp3
    try {
      const audio = new Audio(chrome.runtime.getURL('sounds/complete.mp3'));
      audio.play();
    } catch (e) {
      console.warn('[Packing Recorder] Could not play sound:', e);
    }
  });
  
  // สังเกต document.body ทั้งหมด: subtree + childList + characterData
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
  
  console.log('[Packing Recorder] MutationObserver for order completion is active.');
}

// ============================================================
// Stop recording
// ============================================================
function stopRecording() {
  if (!mediaRecorder || !isRecording) return;
  
  isRecording = false;
  isScanLocked = false; // ปลดล็อคการสแกนเมื่อหยุดอัด
  mediaRecorder.stop();
  
  clearInterval(durationInterval);
  // MutationObserver ทำงานตลอดเวลา ไม่ต้อง clear ที่นี่
  
  // ซ่อน popup ที่อาจค้างอยู่ก่อนสี่ปุ่ม
  const popup = document.getElementById('pr-complete-popup');
  if (popup) popup.style.display = 'none';
  
  // Update UI state
  if (recordBtn) {
    recordBtn.textContent = '▶ เริ่มบันทึก';
    recordBtn.className = 'pr-btn-record-big ready';
  }
  
  const recBadge = floatingPanel.querySelector('.pr-rec-badge');
  if (recBadge) recBadge.classList.add('hidden');
  
  showUploadStatus('normal', '⏹ หยุดบันทึกแล้ว กำลังเตรียมไฟล์...');
}

// ============================================================
// Process recorded chunks and initialize upload flow
// ============================================================
async function finalizeRecording() {
  const durationSec = Math.floor((Date.now() - startTime) / 1000);
  const recordTime = new Date(startTime);
  
  const trackingNo = (currentTrackingNo && currentTrackingNo !== '--') 
    ? currentTrackingNo 
    : (currentOrderNo ? currentOrderNo : `NO_TRACKING_${Date.now()}`);
  const logistics = (currentLogistics && currentLogistics !== '--') ? currentLogistics : 'Unknown';
  
  const yyyy = recordTime.getFullYear();
  const mm = String(recordTime.getMonth() + 1).padStart(2, '0');
  const dd = String(recordTime.getDate()).padStart(2, '0');
  
  const safeTracking = trackingNo.replace(/[^a-zA-Z0-9\-]/g, '_');
  const safeOrderNo = currentOrderNo ? currentOrderNo.replace(/[^a-zA-Z0-9\-]/g, '_') : '';
  const baseName = safeOrderNo ? `${safeTracking}_${safeOrderNo}` : safeTracking;
  
  // Detect format from what was actually recorded
  const recordedMime = mediaRecorder ? mediaRecorder.mimeType : 'video/webm';
  const isMP4 = recordedMime.includes('mp4');
  const fileExt = isMP4 ? 'mp4' : 'webm';
  const blobType = isMP4 ? 'video/mp4' : 'video/webm';
  
  const fileName = `${yyyy}_${mm}_${dd}_${baseName}.${fileExt}`;
  const blob = new Blob(recordedChunks, { type: blobType });
  
  console.log(`[Packing Recorder] Finalizing as ${fileExt.toUpperCase()} (${blobType}), size: ${(blob.size / 1024 / 1024).toFixed(2)}MB`);
  
  // Save local history log first
  const logEntry = {
    tracking_no: trackingNo,
    logistics: logistics,
    file_name: fileName,
    duration_seconds: durationSec,
    status: 'UPLOADING',
    drive_url: null
  };
  await saveLogToHistory(logEntry);
  
  // 1. บันทึก Blob ลง IndexedDB ล่วงหน้าเลย ป้องกันเว็บค้าง/รีเฟรชกลางคัน
  await saveBlobToRetryQueue(blob, fileName, trackingNo, recordTime);
  
  // 2. ข้อมูลสำหรับปุ่ม Retry (ฝังใน RAM เผื่อเกิด Error ระหว่างอัปโหลด)
  window.failedBlobs = window.failedBlobs || {};
  window.failedBlobs[trackingNo] = { blob, fileName, trackingNo, recordTime };
  
  // 3. Start Upload to Drive
  window.activeUploads++;
  await uploadFlow(blob, fileName, trackingNo, recordTime);
  window.activeUploads = Math.max(0, window.activeUploads - 1);
}

// ============================================================
// Drive Upload Flow
// ============================================================
async function uploadFlow(blob, fileName, trackingNo, recordTime) {
  showUploadStatus('uploading', `⏫ กำลังอัปโหลด ${fileName}...`);
  
  // Reload latest token
  await loadConfig();
  
  if (!accessToken) {
    await updateLogStatus(trackingNo, { status: 'FAILED' });
    
    // สำรองข้อมูลลงเครื่อง
    downloadBlobLocally(blob, fileName);
    
    const failedData = { blob, fileName, trackingNo, recordTime };
    window.failedBlobs = window.failedBlobs || {};
    window.failedBlobs[trackingNo] = failedData;
    
    // เก็บ blob ลง IndexedDB เพื่อให้ retry ได้แม้กด Refresh (Already saved before uploadFlow)
    
    showUploadStatus('error', `❌ ล้มเหลว: กรุณาลงชื่อเข้าใช้ (เซฟลงเครื่องแล้ว: ${fileName})`, failedData);
    return;
  }
  
  try {
    const yyyy = recordTime.getFullYear();
    const mm = String(recordTime.getMonth() + 1).padStart(2, '0');
    const dd = String(recordTime.getDate()).padStart(2, '0');
    
    // Ensure Date folder hierarchy
    const dateFolderId = await ensureDateFolderStructure(yyyy, mm, dd);
    
    // Execute Multipart File Upload
    const result = await uploadFileToDrive(blob, fileName, dateFolderId);
    
    await updateLogStatus(trackingNo, {
      status: 'SUCCESS',
      drive_file_id: result.id,
      drive_url: result.webViewLink
    });
    
    // Remove from failedBlobs if it exists (in case this was a retry)
    if (window.failedBlobs) delete window.failedBlobs[trackingNo];
    await removeBlobFromRetryQueue(trackingNo);
    
    showUploadStatus('success', `✅ อัปโหลดสำเร็จ: ${trackingNo}`);
  } catch (err) {
    console.error('Google Drive Upload Failed:', err);
    await updateLogStatus(trackingNo, { status: 'FAILED' });
    
    // 1. สำรองข้อมูลลงเครื่องทันที (Auto Download)
    downloadBlobLocally(blob, fileName);
    
    // 2. ข้อมูลสำหรับปุ่ม Retry
    const failedData = { blob, fileName, trackingNo, recordTime };
    window.failedBlobs = window.failedBlobs || {};
    window.failedBlobs[trackingNo] = failedData;
    
    // Handle specific expired token error
    if (err.message.includes('AuthExpired')) {
      chrome.storage.local.remove(['access_token', 'user_info']); // Clear expired token
      showUploadStatus('error', `❌ เซสชันหมดอายุ! (เซฟลงเครื่องแล้ว: ${fileName})`, failedData);
    } else {
      showUploadStatus('error', `❌ อัปโหลดล้มเหลว! (เซฟลงเครื่องแล้ว: ${fileName})`, failedData);
    }
  }
}

// ============================================================
// Fallback: ดาวน์โหลดลงเครื่องกรณีอัปโหลดล้มเหลว
// ============================================================
function downloadBlobLocally(blob, fileName) {
  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 1000);
    console.log(`[Packing Recorder] บันทึกไฟล์ลงเครื่องเป็น Back-up สำเร็จ: ${fileName}`);
  } catch (err) {
    console.error('ไม่สามารถดาวน์โหลดไฟล์ลงเครื่องได้:', err);
  }
}

// ============================================================
// Google Drive Folder management API helpers
// ============================================================
async function ensureDateFolderStructure(yyyy, mm, dd) {
  const yearId = await getOrCreateFolder(yyyy, folderId);
  const monthId = await getOrCreateFolder(mm, yearId);
  const dayId = await getOrCreateFolder(dd, monthId);
  return dayId;
}

async function getOrCreateFolder(name, parentId) {
  const q = `name='${name}' and '${parentId}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`;
  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)&spaces=drive&includeItemsFromAllDrives=true&supportsAllDrives=true`;
  
  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  
  if (response.status === 401) throw new Error('AuthExpired');
  if (!response.ok) {
    const err = await response.json();
    throw new Error(`Drive folder query error: ${err.error?.message || response.statusText}`);
  }
  
  const data = await response.json();
  const files = data.files || [];
  
  if (files.length > 0) {
    return files[0].id;
  }
  
  // Create Folder if not exists
  const createResp = await fetch('https://www.googleapis.com/drive/v3/files?supportsAllDrives=true', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: name,
      mimeType: 'application/vnd.google-apps.folder',
      parents: [parentId]
    })
  });
  
  if (createResp.status === 401) throw new Error('AuthExpired');
  if (!createResp.ok) {
    const err = await createResp.json();
    throw new Error(`Drive folder creation error: ${err.error?.message || createResp.statusText}`);
  }
  
  const folder = await createResp.json();
  return folder.id;
}

async function uploadFileToDrive(blob, fileName, dateFolderId) {
  return new Promise((resolve, reject) => {
    const metadata = {
      name: fileName,
      parents: [dateFolderId],
      mimeType: blob.type
    };
    
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', blob);
    
    const uploadUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink&supportsAllDrives=true';
    
    const xhr = new XMLHttpRequest();
    xhr.open('POST', uploadUrl, true);
    xhr.setRequestHeader('Authorization', `Bearer ${accessToken}`);
    
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        const percent = Math.round((event.loaded / event.total) * 100);
        updateUploadProgressUI(percent, fileName);
      }
    };
    
    xhr.onload = () => {
      if (xhr.status === 401) {
        reject(new Error('AuthExpired'));
      } else if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const resp = JSON.parse(xhr.responseText);
          resolve(resp);
        } catch(e) {
          reject(e);
        }
      } else {
        reject(new Error(`File upload error: ${xhr.statusText}`));
      }
    };
    
    xhr.onerror = () => reject(new Error('Network Error'));
    
    xhr.send(form);
  });
}

function updateUploadProgressUI(percent, fileName) {
  const el = document.getElementById('pr-upload-status');
  if (el && el.className.includes('uploading')) {
    el.innerHTML = `
      <div class="pr-upload-progress-bar" style="width: ${percent}%;"></div>
      <span class="pr-spinner"></span><span style="position: relative; z-index: 2;">⏫ กำลังอัปโหลด ${fileName} (${percent}%)</span>
    `;
  }
}

// ============================================================
// Show Alert notification in inline Status div
// ============================================================
function showUploadStatus(type, message, failedData = null) {
  const el = document.getElementById('pr-upload-status');
  if (!el) return;
  
  el.className = 'pr-upload-status show ' + type;
  
  if (type === 'uploading') {
    el.innerHTML = `
      <div class="pr-upload-progress-bar" style="width: 0%;"></div>
      <span class="pr-spinner"></span><span style="position: relative; z-index: 2;">${message}</span>
    `;
  } else if (failedData) {
    // ถ้ามี failedData แสดงปุ่ม Retry
    lastFailedUpload = failedData;
    el.innerHTML = `
      <span style="position: relative; z-index: 2;">${message}</span>
      <button id="pr-btn-retry-upload" style="position: relative; z-index: 2; margin-left:12px; padding:4px 10px; border-radius:6px; border:none; background:#fff; color:#ef4444; font-weight:bold; cursor:pointer; font-family:inherit; box-shadow:0 2px 5px rgba(0,0,0,0.2);">
        🔄 ลองใหม่
      </button>
    `;
    // ผูก Event ให้ปุ่ม Retry
    document.getElementById('pr-btn-retry-upload').addEventListener('click', () => {
      if (lastFailedUpload) {
        el.className = 'pr-upload-status'; // ซ่อน error ตัวเดิม
        uploadFlow(lastFailedUpload.blob, lastFailedUpload.fileName, lastFailedUpload.trackingNo, lastFailedUpload.recordTime);
      }
    });
  } else {
    el.innerHTML = `<span style="position: relative; z-index: 2;">${message}</span>`;
  }
  
  // Auto-hide success/error after 6 seconds (ยกเว้นกำลังอัปโหลด หรือ มีปุ่ม Retry)
  if (type !== 'uploading' && !failedData) {
    setTimeout(() => { el.className = 'pr-upload-status'; }, 6000);
  }
}

// ============================================================
// Inject Floating panel into BigSeller DOM
// ============================================================
function injectFloatingPanel() {
  if (document.getElementById('pr-floating-panel')) return;
  
  // ดัน BigSeller body ให้แคบลงเพื่อเปิดที่ให้ sidebar (UI Integration)
  document.documentElement.style.setProperty('--pr-sidebar-width', '300px');
  document.body.style.width = 'calc(100% - 300px)';
  document.body.style.transition = 'width 0.3s ease-in-out';
  // ดัน fixed/absolute elements ของ BigSeller ที่ตรึงขวา
  document.body.style.position = 'relative';

  floatingPanel = document.createElement('div');
  floatingPanel.id = 'pr-floating-panel';
  floatingPanel.innerHTML = `
<!-- Toggle Button -->
<div class="pr-toggle-sidebar" id="pr-toggle-sidebar">&gt;</div>
<!-- Header -->
<div class="pr-header">
  <div class="pr-title">
    <img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="Logo" style="width:20px;height:20px;margin-right:6px;vertical-align:middle;border-radius:4px;">
    Packing Recorder
  </div>
</div>
<div class="pr-body">
  <!-- Big Pack Counter -->
  <div class="pr-counter-box">
    <div class="pr-counter-label">วันนี้แพ็คแล้ว</div>
    <div class="pr-counter-number" id="pr-pack-count">0</div>
    <div class="pr-counter-unit">ชิ้น</div>
  </div>
  <!-- Status Indicators -->
  <div class="pr-status-indicators">
    <div id="pr-ind-login" class="pr-indicator">
      <span class="pr-ind-dot grey"></span>
      <span class="pr-ind-label">ล็อกอิน: ตรวจสอบ...</span>
    </div>
    <div id="pr-ind-system" class="pr-indicator">
      <span class="pr-ind-dot grey"></span>
      <span class="pr-ind-label">ระบบ: ตรวจสอบ...</span>
    </div>
    <div id="pr-ind-camera" class="pr-indicator">
      <span class="pr-ind-dot grey"></span>
      <span class="pr-ind-label">กล้อง: ตรวจสอบ...</span>
    </div>
  </div>
  <!-- Camera Preview -->
  <div class="pr-preview-container">
    <video id="pr-video-hidden" autoplay playsinline muted></video>
    <canvas id="pr-canvas-preview" width="1280" height="720"></canvas>
    <div class="pr-placeholder">
      <span class="pr-placeholder-icon">📸</span>
      <span>กำลังโหลดกล้อง...</span>
    </div>
    <div class="pr-rec-badge hidden">
      <span class="pr-dot pulsing"></span>
      <span>REC</span>
      <span id="pr-duration">00:00</span>
    </div>
  </div>
  <!-- Upload Status (shown inline, replaces old status bar) -->
  <div class="pr-upload-status" id="pr-upload-status"></div>
  <!-- Tracking Big -->
  <div class="pr-tracking-big">
    <div class="pr-tracking-number" id="pr-tracking-val">-</div>
    <div class="pr-tracking-logistics" id="pr-logistics-val">รอสแกน...</div>
  </div>
  <!-- History -->
  <div class="pr-history-section">
    <div class="pr-history-header">
      <span>📋 ประวัติวันนี้</span>
      <span class="pr-history-badge" id="pr-history-count">0 รายการ</span>
    </div>
    <div id="pr-history-list">
      <div class="pr-history-empty">ยังไม่มีรายการวันนี้</div>
    </div>
  </div>
  <!-- Settings gear -->
  <button class="pr-btn-gear" id="pr-btn-settings">⚙️ ตั้งค่ากล้อง</button>
  <div class="pr-settings-panel" id="pr-settings-panel">
    <div class="pr-field">
      <label>เลือกกล้อง (Camera)</label>
      <select class="pr-select" id="pr-camera-select">
        <option value="">-- โหลดกล้อง --</option>
      </select>
    </div>
    <label class="pr-checkbox-row">
      <input type="checkbox" id="pr-auto-record-check" checked>
      <span>เริ่มอัดอัตโนมัติเมื่อสแกนพัสดุ</span>
    </label>
  </div>
</div>
  `;
  
  document.body.appendChild(floatingPanel);
  
  // Inject Login Warning Overlay
  if (!document.getElementById('pr-login-overlay')) {
    const overlay = document.createElement('div');
    overlay.id = 'pr-login-overlay';
    overlay.className = 'pr-login-overlay';
    overlay.innerHTML = `
      <div class="pr-login-card" style="background: rgba(15,23,42,0.95); padding: 40px 48px; border-radius: 20px; border: 2px solid #ef4444; text-align: center; max-width: 520px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);">
        <h1 style="color:#ef4444; font-size: 2.2rem; margin-bottom: 16px; font-weight: 800; font-family: 'Inter', sans-serif;">⚠️ กรุณาลงชื่อเข้าใช้ Google Drive</h1>
        <p style="color:#cbd5e1; font-size: 1.1rem; margin-bottom: 24px; line-height: 1.5; font-family: 'Inter', sans-serif;">ระบบจำเป็นต้องลงชื่อเข้าใช้ เพื่อให้สามารถบันทึกและอัปโหลดวิดีโอเข้าโฟลเดอร์ได้เรียบร้อย</p>
        <button id="pr-btn-overlay-login" style="padding: 14px 32px; font-size: 1.15rem; font-weight: 700; background: #3b82f6; color: #fff; border: none; border-radius: 12px; cursor: pointer; box-shadow: 0 4px 15px rgba(59,130,246,0.4); font-family: inherit; transition: background 0.2s;">
          🔑 คลิกที่นี่เพื่อลงชื่อเข้าใช้ Google Drive
        </button>
      </div>
    `;
    document.body.appendChild(overlay);

    const loginBtn = overlay.querySelector('#pr-btn-overlay-login');
    if (loginBtn) {
      loginBtn.addEventListener('click', () => {
        loginBtn.disabled = true;
        loginBtn.textContent = '⏳ กำลังเข้าสู่ระบบ...';
        chrome.runtime.sendMessage({ action: 'START_AUTH', clientId }, (resp) => {
          loginBtn.disabled = false;
          loginBtn.textContent = '🔑 คลิกที่นี่เพื่อลงชื่อเข้าใช้ Google Drive';
          if (resp && resp.success) {
            accessToken = resp.access_token;
            hideLoginOverlay();
            updateStatusIndicators();
            showUploadStatus('success', '✅ ลงชื่อเข้าใช้สำเร็จแล้ว!');
          } else {
            alert('การลงชื่อเข้าใช้ล้มเหลว: ' + (resp?.error || 'Unknown error'));
          }
        });
      });
    }
  }

  // Inject Order Complete Popup
  if (!document.getElementById('pr-complete-popup')) {
    const popup = document.createElement('div');
    popup.id = 'pr-complete-popup';
    popup.className = 'pr-complete-popup';
    popup.innerHTML = `
      <div class="pr-popup-card">
        <div class="pr-popup-icon">✅</div>
        <h2>สแกนครบแล้ว!</h2>
        <p>วิดีโอกำลังบันทึกอยู่ กรุณาแพ็คสินค้าให้เรียบร้อย</p>
        <button class="pr-btn-pack-complete" id="pr-btn-pack-complete">รับทราบ</button>
      </div>
    `;
    document.body.appendChild(popup);
  }
  
  // Element caching
  streamVideo = document.getElementById('pr-video-hidden');
  canvasElement = document.getElementById('pr-canvas-preview');
  canvasCtx = canvasElement.getContext('2d');
  
  durationBadge = document.getElementById('pr-duration');
  trackingValEl = document.getElementById('pr-tracking-val');
  logisticsValEl = document.getElementById('pr-logistics-val');
  
  cameraSelect = document.getElementById('pr-camera-select');
  autoRecordCheck = document.getElementById('pr-auto-record-check');
  settingsPanel = document.getElementById('pr-settings-panel');
  
  // Hook Interactive Panel Events
  setupPanelEvents();
}

// ============================================================
// Setup Interactive Panel Events
// ============================================================
function setupPanelEvents() {
  // Toggle Sidebar
  const toggleBtn = document.getElementById('pr-toggle-sidebar');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      if (floatingPanel) {
        floatingPanel.classList.toggle('collapsed');
        const isCollapsed = floatingPanel.classList.contains('collapsed');
        toggleBtn.innerHTML = isCollapsed ? '&lt;' : '&gt;';
        
        // ดัน body กลับเมื่อยุบ sidebar
        document.body.style.width = isCollapsed ? '100%' : 'calc(100% - 300px)';
      }
    });
  }

  // Pack Complete Button — ปิด Popup และปลดล็อค Scan Lock (วิดีโอยังอัดต่อจนกว่าจะกด ล้างข้อมูล & สแกนถัดไป)
  const packCompleteBtn = document.getElementById('pr-btn-pack-complete');
  if (packCompleteBtn) {
    packCompleteBtn.addEventListener('click', () => {
      const popup = document.getElementById('pr-complete-popup');
      if (popup) popup.style.display = 'none';
      
      // ปลดล็อค Scan Lock
      isScanLocked = false;
      
      // วิดีโอยังคงอัดภาพการแพ็คสินค้า ปิดกล่อง ต่อไปเรื่อยๆ จนกว่าจะกด "ล้างข้อมูล & สแกนถัดไป" บน BigSeller
    });
  }

  // Toggle Settings Panel
  const settingsBtn = document.getElementById('pr-btn-settings');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
      if (settingsPanel) settingsPanel.classList.toggle('open');
    });
  }
  
  // Select Camera Change
  if (cameraSelect) {
    cameraSelect.addEventListener('change', (e) => {
      initCamera(e.target.value);
    });
  }
  
  // Toggle Auto Record Checkbox
  if (autoRecordCheck) {
    autoRecordCheck.addEventListener('change', (e) => {
      autoRecordEnabled = e.target.checked;
      chrome.storage.local.set({ auto_record_enabled: autoRecordEnabled });
    });
  }
}

// ============================================================
// Update Pack Count
// ============================================================
async function updatePackCount() {
  const packCountEl = document.getElementById('pr-pack-count');
  if (!packCountEl) return;

  const data = await chrome.storage.local.get(['scan_history']);
  const history = data.scan_history || [];
  const todayStr = new Date().toISOString().split('T')[0];
  
  // Count SUCCESS items today
  const todaySuccessItems = history.filter(item => 
    item.created_at.startsWith(todayStr) && item.status === 'SUCCESS'
  );
  
  packCountEl.textContent = todaySuccessItems.length;
}

// ============================================================
// Update status indicator dots
// ============================================================
function updateStatusIndicators() {
  const loginEl = document.getElementById('pr-ind-login');
  const systemEl = document.getElementById('pr-ind-system');
  const cameraEl = document.getElementById('pr-ind-camera');
  
  if (loginEl) {
    const dot = loginEl.querySelector('.pr-ind-dot');
    const label = loginEl.querySelector('.pr-ind-label');
    if (dot && label) {
      dot.className = 'pr-ind-dot ' + (accessToken ? 'green' : 'orange');
      label.textContent = accessToken ? 'ล็อกอิน: พร้อม' : 'ล็อกอิน: ยังไม่ได้เชื่อมต่อ';
    }
  }
  
  if (systemEl) {
    const dot = systemEl.querySelector('.pr-ind-dot');
    const label = systemEl.querySelector('.pr-ind-label');
    if (dot && label) {
      dot.className = 'pr-ind-dot ' + (isExtensionEnabled ? 'green' : 'red');
      label.textContent = isExtensionEnabled ? 'ระบบ: พร้อม' : 'ระบบ: ปิดการทำงาน';
    }
  }

  if (cameraEl) {
    const dot = cameraEl.querySelector('.pr-ind-dot');
    const label = cameraEl.querySelector('.pr-ind-label');
    if (dot && label) {
      const cameraReady = streamVideo && streamVideo.srcObject && streamVideo.readyState >= 2;
      dot.className = 'pr-ind-dot ' + (cameraReady ? 'green' : 'red');
      label.textContent = cameraReady ? 'กล้อง: พร้อม' : 'กล้อง: ไม่ได้เชื่อมต่อ';
    }
  }
}

// ============================================================
// Render today's history in sidebar
// ============================================================
async function renderSidebarHistory() {
  const listEl = document.getElementById('pr-history-list');
  const countEl = document.getElementById('pr-history-count');
  if (!listEl) return;

  const data = await chrome.storage.local.get(['scan_history']);
  const history = data.scan_history || [];
  const todayStr = new Date().toISOString().split('T')[0];
  const todayItems = history.filter(item => item.created_at.startsWith(todayStr));

  if (countEl) countEl.textContent = `${todayItems.length} รายการ`;

  if (todayItems.length === 0) {
    listEl.innerHTML = '<div class="pr-history-empty">ยังไม่มีรายการวันนี้</div>';
    return;
  }

    listEl.innerHTML = todayItems.map(item => {
    const elapsedM = String(Math.floor(item.duration_seconds / 60)).padStart(2, '0');
    const elapsedS = String(item.duration_seconds % 60).padStart(2, '0');
    const timeLocal = new Date(item.created_at).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' });
    const statusIcon = item.status === 'SUCCESS' ? '✅' : item.status === 'UPLOADING' ? '⏫' : '❌';
    
    let retryBtnHtml = '';
    if (item.status === 'FAILED' && window.failedBlobs && window.failedBlobs[item.tracking_no]) {
      retryBtnHtml = `<div style="margin-top:6px;"><button class="pr-hist-retry" data-tracking="${item.tracking_no}" style="font-size:11px; padding:3px 8px; background:#ef4444; color:#fff; border:none; border-radius:4px; cursor:pointer;">🔄 ลองอัปโหลดใหม่</button></div>`;
    }

    return `
      <div class="pr-hist-item">
        <div class="pr-hist-top">
          <span class="pr-hist-tracking">${item.tracking_no}</span>
          <span>${statusIcon}</span>
        </div>
        <div class="pr-hist-meta">${item.logistics} · ⏱ ${elapsedM}:${elapsedS} · ${timeLocal}</div>
        ${item.drive_url ? `<a href="${item.drive_url}" target="_blank" class="pr-hist-link">↗ เปิดใน Drive</a>` : ''}
        ${retryBtnHtml}
      </div>
    `;
  }).join('');
}

// Helper: Focus กลับไปยังช่องสแกนแทร็คกิ้งบน BigSeller
function focusTrackingInput() {
  const trackingInput = document.querySelector('input[placeholder*="แทร็คกิ้ง"], input[placeholder*="พัสดุ"], input[placeholder*="คำสั่งซื้อ"]');
  if (trackingInput) {
    trackingInput.focus();
    trackingInput.select();
  }
}

// ============================================================
// Hook BigSeller UI scan inputs and clear buttons
// ============================================================
function hookBigSellerEvents() {
  console.log('Hooking BigSeller inputs and buttons...');

  // Global Interceptor: บล็อกทุก Event keydown / input บนหน้าเว็บหากกำลังติด isScanLocked
  window.addEventListener('keydown', (e) => {
    if (isScanLocked) {
      e.preventDefault();
      e.stopPropagation();
      if (document.activeElement && document.activeElement.tagName === 'INPUT') {
        document.activeElement.blur();
      }
      return false;
    }
  }, true);

  window.addEventListener('input', (e) => {
    if (isScanLocked) {
      e.preventDefault();
      e.stopPropagation();
      return false;
    }
  }, true);

  // Event Delegation for scan inputs and clear buttons
  
  // 1. Hook the input for scanning
  document.body.addEventListener('keydown', (e) => {
    if (isScanLocked) return;

    const input = e.target;
    const placeholder = input.placeholder || '';
    
    // Check if the input is explicitly the tracking input
    const isTrackingInput = placeholder.includes('แทร็คกิ้ง') || 
                            placeholder.includes('คำสั่งซื้อ') || 
                            placeholder.includes('พัสดุ') ||
                            placeholder.toLowerCase().includes('tracking');
                           
    if (isTrackingInput && e.key === 'Enter') {
      console.log('BigSeller barcode scan submitted.');
      
      if (!autoRecordEnabled || !isExtensionEnabled) return;
      
      // Delay slightly to let BigSeller update the tracking number or logistics on the screen
      setTimeout(async () => {
        // If already recording, IGNORE this scan to prevent double records
        if (isRecording) {
          console.log('Already recording. Ignoring this tracking scan to prevent double-record.');
          return;
        }
        
        // Normal case: Start recording
        if (!accessToken) {
           const overlay = document.getElementById('pr-login-overlay');
           if (overlay) overlay.style.display = 'flex';
           return;
        }
        
        // ล้างค่าเก่าก่อน scrape ใหม่
        currentTrackingNo = '';
        currentOrderNo = '';
        currentLogistics = '';
        
        // Scrape ด้วย retry — รอ BigSeller DOM อัปเดตสูงสุด 2 วินาที (Bug #4)
        let retryCount = 0;
        const maxRetries = 5;
        
        while (retryCount < maxRetries) {
          scrapeTrackingAndLogistics();
          if (currentLogistics && currentLogistics !== '--') break;
          retryCount++;
          if (retryCount < maxRetries) {
            await new Promise(r => setTimeout(r, 400));
          }
        }
        
        startRecording();
      }, 500);
    }
  });

  // 2. Hook the "ล้างข้อมูล & สแกนถัดไป" Button to stop recording
  document.body.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    
    const btnText = btn.textContent.trim();
    if (btnText.includes('ล้างข้อมูล') && btnText.includes('สแกนถัดไป')) {
      console.log('Clicked "ล้างข้อมูล & สแกนถัดไป" button. Stopping video...');
      if (isRecording) {
        stopRecording();
      }
    }
  });
  
  // 3. Hook Retry button in history list
  const historyListEl = document.getElementById('pr-history-list');
  if (historyListEl) {
    historyListEl.addEventListener('click', (e) => {
      const btn = e.target.closest('.pr-hist-retry');
      if (!btn) return;
      const tracking = btn.dataset.tracking;
      if (window.failedBlobs && window.failedBlobs[tracking]) {
        const data = window.failedBlobs[tracking];
        // uploadFlow จะจัดการการอัปเดตสถานะเป็น UPLOADING ให้อัตโนมัติ
        uploadFlow(data.blob, data.fileName, data.trackingNo, data.recordTime);
      }
    });
  }
  
  // ตั้ง MutationObserver เพื่อตรวจจับการแพ็คสำเร็จจากตาราง shipped_list
  setupOrderObserver();
}

// ============================================================
// Main Bootstrapping
// ============================================================
(async () => {
  // URL Restriction — manifest.json handles this now, but keep as safety net for mock page
  const currentUrl = window.location.href;
  if (!currentUrl.includes('/web/order/scanToInspection.htm') && !currentUrl.includes('mock_bigseller.html')) {
    return;
  }

  // Load configuration first
  await loadConfig();
  
  // Restore configs from storage
  const storage = await chrome.storage.local.get(['selected_device_id', 'auto_record_enabled', 'extension_enabled']);
  if (storage.selected_device_id) activeDeviceId = storage.selected_device_id;
  if (storage.hasOwnProperty('auto_record_enabled')) autoRecordEnabled = storage.auto_record_enabled;
  if (storage.hasOwnProperty('extension_enabled')) isExtensionEnabled = storage.extension_enabled;
  
  // Inject CSS styles and construct sidebar
  injectFloatingPanel();
  
  // Validate Auth Token on page load (shows overlay with 🔑 Sign In button if token expired/missing)
  await validateAuthTokenOnBoot();
  
  if (autoRecordCheck) autoRecordCheck.checked = autoRecordEnabled;
  
  // Start drawing canvas overlays
  drawCanvasLoop();
  
  // Request webcam & configure camera settings
  await initCamera(activeDeviceId);
  
  // Update status dots after camera init
  updateStatusIndicators();
  
  // Retry updating indicators in case camera takes longer to be ready
  setTimeout(updateStatusIndicators, 2000);

  // Update pack count & history
  await updatePackCount();
  await renderSidebarHistory();
  
  // โหลด failed upload blobs จาก IndexedDB (ถ้ามี) → แสดงปุ่ม Retry ทันที
  const pendingCount = await loadRetryQueueFromDB();
  if (pendingCount > 0) {
    await renderSidebarHistory(); // Re-render เพื่อแสดงปุ่ม Retry
    showUploadStatus('error', `⚠️ มี ${pendingCount} วิดีโอที่ยังอัปโหลดไม่สำเร็จ กรุณากดปุ่ม "ลองใหม่"`);
  }
  
  // Hook DOM observers and events
  hookBigSellerEvents();
  
  // เริ่ม Token Expiry Watchdog
  startTokenWatchdog();
  
  // Listen for messages from popup (toggle)
  chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'SET_ENABLED') {
      isExtensionEnabled = request.enabled;
      if (!isExtensionEnabled && isRecording) stopRecording();
    }
  });

  // Listen for storage changes to hot-reload configs
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
      if (changes.access_token) {
        accessToken = changes.access_token.newValue;
        updateStatusIndicators();
        // Hide login overlay if token becomes available
        if (accessToken) {
          const overlay = document.getElementById('pr-login-overlay');
          if (overlay) overlay.style.display = 'none';
        }
      }
      if (changes.gcp_client_id) clientId = changes.gcp_client_id.newValue;
      if (changes.gcp_folder_id) folderId = changes.gcp_folder_id.newValue;
      if (changes.extension_enabled) isExtensionEnabled = changes.extension_enabled.newValue;
      if (changes.scan_history) {
        renderSidebarHistory();
        updatePackCount();
      }
    }
  });
})();
